// ─── QwikTools core: tool registry, persistent store, utilities ───

export type CategoryKey = "qr" | "image" | "pdf" | "calc" | "text";

export interface ToolDef {
  key: string;
  name: string;
  tagline: string;
  category: CategoryKey;
  icon: string; // lucide icon name key resolved in UI
  tint: "mint" | "lilac" | "peach" | "ink" | "cream";
  keywords: string[];
  pro?: boolean;
}

export const CATEGORIES: { key: CategoryKey | "all"; label: string; blurb: string; tint: string }[] = [
  { key: "all", label: "All", blurb: "Every tool", tint: "#111111" },
  { key: "qr", label: "QR", blurb: "Scan & create", tint: "#CDEFE6" },
  { key: "image", label: "Image", blurb: "Compress & convert", tint: "#E8D8F6" },
  { key: "pdf", label: "PDF", blurb: "Build & merge", tint: "#F4D9C6" },
  { key: "calc", label: "Calculator", blurb: "Math quickly", tint: "#FDF6E9" },
  { key: "text", label: "Text & Security", blurb: "Words & secrets", tint: "#111111" },
];

export const TOOLS: ToolDef[] = [
  { key: "qr-scanner", name: "QR Scanner", tagline: "Scan with camera or image", category: "qr", icon: "scan-line", tint: "mint", keywords: ["qr", "scan", "camera", "code", "read", "barcode"] },
  { key: "qr-generator", name: "QR Generator", tagline: "Link, text, Wi-Fi & more", category: "qr", icon: "qr-code", tint: "ink", keywords: ["qr", "generate", "create", "wifi", "contact", "whatsapp", "link"] },
  { key: "image-compressor", name: "Image Compressor", tagline: "Shrink size, keep quality", category: "image", icon: "minimize-2", tint: "lilac", keywords: ["compress", "shrink", "size", "optimize", "reduce", "image", "photo"] },
  { key: "image-resizer", name: "Image Resizer", tagline: "Pixels, presets & aspect", category: "image", icon: "scaling", tint: "peach", keywords: ["resize", "dimensions", "pixels", "scale", "width", "height"] },
  { key: "image-converter", name: "Format Converter", tagline: "JPG · PNG · WebP", category: "image", icon: "repeat", tint: "mint", keywords: ["convert", "format", "jpg", "png", "webp", "type"] },
  { key: "images-to-pdf", name: "Images to PDF", tagline: "Photos into one document", category: "pdf", icon: "file-image", tint: "peach", keywords: ["images to pdf", "pdf", "photos", "document", "create"] },
  { key: "pdf-to-images", name: "PDF to Images", tagline: "Pages as JPG or PNG", category: "pdf", icon: "file-stack", tint: "lilac", keywords: ["pdf to images", "extract", "pages", "jpg", "png", "render"] },
  { key: "pdf-merge", name: "PDF Merge", tagline: "Combine PDFs in order", category: "pdf", icon: "combine", tint: "ink", keywords: ["merge", "combine", "join", "pdf", "append"] },
  { key: "percentage", name: "Percentage Calculator", tagline: "X% of Y in one tap", category: "calc", icon: "percent", tint: "mint", keywords: ["percent", "percentage", "discount", "tip", "increase", "math"] },
  { key: "unit-converter", name: "Unit Converter", tagline: "Length, weight, temp…", category: "calc", icon: "ruler", tint: "cream", keywords: ["unit", "convert", "length", "weight", "temperature", "speed", "data"] },
  { key: "password", name: "Password Generator", tagline: "Strong & offline", category: "text", icon: "key-round", tint: "ink", keywords: ["password", "secure", "random", "generator", "pass"] },
  { key: "word-counter", name: "Word Counter", tagline: "Live words & reading time", category: "text", icon: "text", tint: "peach", keywords: ["word", "count", "counter", "characters", "text", "reading"] },
];

export type ViewKey =
  | "home" | "tools" | "history" | "pro" | "settings" | "search"
  | "cat-qr" | "cat-image" | "cat-pdf" | "cat-calc" | "cat-text"
  | string; // tool keys

// ─── history ───
export interface HistoryItem {
  id: string;
  featureKey: string;
  toolName: string;
  timestamp: number;
  status: "success" | "cancelled" | "error";
  detail: string;
  meta?: string;
  favorite?: boolean;
}

const HKEY = "qwiktools.history.v1";
const FKEY = "qwiktools.favs.v1";
const RKEY = "qwiktools.recent.v1";
const SKEY = "qwiktools.settings.v1";
const OKEY = "qwiktools.onboarded.v1";
const PKEY = "qwiktools.pro.v1";
const SEARCHKEY = "qwiktools.searches.v1";

export function loadHistory(): HistoryItem[] {
  try { return JSON.parse(localStorage.getItem(HKEY) || "[]"); } catch { return []; }
}
export function saveHistory(items: HistoryItem[]) {
  try { localStorage.setItem(HKEY, JSON.stringify(items.slice(0, 200))); } catch {}
}
export function pushHistory(entry: Omit<HistoryItem, "id" | "timestamp"> & { timestamp?: number }) {
  const items = loadHistory();
  const item: HistoryItem = {
    id: Math.random().toString(36).slice(2) + Date.now().toString(36),
    timestamp: Date.now(),
    ...entry,
  } as HistoryItem;
  // don't log password values
  items.unshift(item);
  saveHistory(items);
  window.dispatchEvent(new CustomEvent("qwik-history"));
  return item;
}

export function loadFavs(): string[] {
  try { return JSON.parse(localStorage.getItem(FKEY) || "[]"); } catch { return []; }
}
export function toggleFav(key: string): string[] {
  const f = loadFavs();
  const next = f.includes(key) ? f.filter((k) => k !== key) : [...f, key];
  localStorage.setItem(FKEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent("qwik-favs"));
  return next;
}

export function loadRecent(): string[] {
  try { return JSON.parse(localStorage.getItem(RKEY) || "[]"); } catch { return []; }
}
export function touchRecent(key: string) {
  try {
    const r = [key, ...loadRecent().filter((k) => k !== key)].slice(0, 8);
    localStorage.setItem(RKEY, JSON.stringify(r));
    window.dispatchEvent(new CustomEvent("qwik-recent"));
  } catch {}
}

export interface AppSettings {
  quality: number;
  format: string;
  pageSize: string;
  historyEnabled: boolean;
  autoDeleteTemp: boolean;
  reduceMotion: boolean;
}
export const DEFAULT_SETTINGS: AppSettings = {
  quality: 80, format: "webp", pageSize: "A4", historyEnabled: true, autoDeleteTemp: true, reduceMotion: false,
};
export function loadSettings(): AppSettings {
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SKEY) || "{}") }; } catch { return DEFAULT_SETTINGS; }
}
export function saveSettings(s: AppSettings) {
  localStorage.setItem(SKEY, JSON.stringify(s));
  window.dispatchEvent(new CustomEvent("qwik-settings"));
}

export function isOnboarded() { return localStorage.getItem(OKEY) === "1"; }
export function setOnboarded() { localStorage.setItem(OKEY, "1"); }
export function isPro() { return localStorage.getItem(PKEY) === "1"; }
export function setPro(v: boolean) {
  localStorage.setItem(PKEY, v ? "1" : "0");
  window.dispatchEvent(new CustomEvent("qwik-pro"));
}

export function loadSearches(): string[] {
  try { return JSON.parse(localStorage.getItem(SEARCHKEY) || "[]"); } catch { return []; }
}
export function pushSearch(q: string) {
  if (!q.trim()) return;
  try {
    const s = [q.trim(), ...loadSearches().filter((x) => x.toLowerCase() !== q.trim().toLowerCase())].slice(0, 6);
    localStorage.setItem(SEARCHKEY, JSON.stringify(s));
  } catch {}
}

// ─── utils ───
export function fmtBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "—";
  if (n === 0) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  const v = n / Math.pow(1024, i);
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
}
export function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "Just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 86400 * 7) return `${Math.floor(s / 86400)}d ago`;
  return new Date(ts).toLocaleDateString();
}
export function fullDate(ts: number) {
  return new Date(ts).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
export function downloadUrl(url: string, name: string) {
  const a = document.createElement("a");
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
}
export function uid() { return Math.random().toString(36).slice(2, 9); }

export function detectQrKind(text: string): { kind: string; label: string } {
  const t = text.trim();
  if (/^WIFI:/i.test(t)) return { kind: "wifi", label: "Wi-Fi credentials" };
  if (/^https?:\/\//i.test(t)) return { kind: "url", label: "Website link" };
  if (/^mailto:/i.test(t) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)) return { kind: "email", label: "Email address" };
  if (/^tel:/i.test(t) || /^\+?[\d\s\-()]{7,}$/.test(t)) return { kind: "phone", label: "Phone number" };
  if (/^BEGIN:VCARD/i.test(t)) return { kind: "contact", label: "Contact card" };
  if (/^smsto:|^sms:/i.test(t)) return { kind: "sms", label: "SMS" };
  if (/^whatsapp:/i.test(t)) return { kind: "whatsapp", label: "WhatsApp" };
  if (t.length <= 280) return { kind: "text", label: "Plain text" };
  return { kind: "text", label: "Text payload" };
}

export function tintBg(tint: ToolDef["tint"]): string {
  switch (tint) {
    case "mint": return "#CDEFE6";
    case "lilac": return "#E8D8F6";
    case "peach": return "#F4D9C6";
    case "cream": return "#FDF6E9";
    default: return "#111111";
  }
}
export function tintFg(tint: ToolDef["tint"]): string {
  return tint === "ink" ? "#F7F7F4" : "#111111";
}
