import { useEffect, useRef, useState } from "react";
import { ImagePlus, X, Download, ArrowUp, ArrowDown, FileText, FileImage, Combine, Eye } from "lucide-react";
import { jsPDF } from "jspdf";
import { PDFDocument } from "pdf-lib";
import JSZip from "jszip";
import { downloadUrl, fmtBytes, loadSettings, pushHistory, touchRecent, uid } from "../lib/core";
import { ActionBar, OfflineBadge, ProcessingOverlay, ResultCard, ToolHeader } from "../components/chrome";
import { TOOLS } from "../lib/core";

// configure pdf.js worker once (lazy import to keep initial bundle snappy is handled by vite)
let pdfjsConfigured = false;
async function getPdfJs() {
  const pdfjs: any = await import("pdfjs-dist");
  if (!pdfjsConfigured) {
    try { pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.mjs`; } catch {}
    pdfjsConfigured = true;
  }
  return pdfjs;
}

// ─── shared image item ───
interface PImg { id: string; url: string; name: string; size: number; w: number; h: number; }
async function toPImg(f: File): Promise<PImg> {
  const url = URL.createObjectURL(f);
  const d = await new Promise<{ w: number; h: number }>((res) => {
    const i = new Image();
    i.onload = () => res({ w: i.naturalWidth, h: i.naturalHeight });
    i.onerror = () => res({ w: 1200, h: 800 });
    i.src = url;
  });
  return { id: uid(), url, name: f.name, size: f.size, w: d.w, h: d.h };
}

// ─── IMAGES TO PDF ───
export function ImagesToPdf({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "images-to-pdf")!;
  const [items, setItems] = useState<PImg[]>([]);
  const [dragId, setDragId] = useState<string | null>(null);
  const [pageSize, setPageSize] = useState<"Auto" | "A4" | "Letter">("Auto");
  const [orient, setOrient] = useState<"portrait" | "landscape">("portrait");
  const [fit, setFit] = useState<"fit" | "fill">("fit");
  const [name, setName] = useState("qwiktools-document");
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [out, setOut] = useState<{ url: string; size: number; pages: number } | null>(null);
  const cancelRef = useRef(false);
  useEffect(() => { touchRecent("images-to-pdf"); }, []);

  const add = async (fl: FileList | null) => {
    if (!fl) return;
    const arr = Array.from(fl).filter((f) => f.type.startsWith("image/")).slice(0, 20 - items.length);
    const mapped = await Promise.all(arr.map(toPImg));
    setItems((p) => [...p, ...mapped]);
    setOut(null);
  };
  const move = (id: string, dir: -1 | 1) => {
    setItems((p) => {
      const i = p.findIndex((x) => x.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= p.length) return p;
      const n = [...p]; [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };

  const create = async () => {
    if (!items.length) return;
    cancelRef.current = false;
    setJob({ cur: 0, total: items.length });
    try {
      const load = (u: string) => new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = u; });
      let pdf: jsPDF | null = null;
      for (let idx = 0; idx < items.length; idx++) {
        if (cancelRef.current) return;
        const it = items[idx];
        const img = await load(it.url);
        let pw = 210, ph = 297; // mm A4 portrait default
        if (pageSize === "Letter") { pw = 215.9; ph = 279.4; }
        if (pageSize === "Auto") { const r = img.naturalWidth / img.naturalHeight; if (orient === "landscape") { pw = 297; ph = 297 / r; } else { pw = 210; ph = 210 / r; } }
        if (orient === "landscape" && pageSize !== "Auto") { const t = pw; pw = ph; ph = t; }
        if (!pdf) pdf = new jsPDF({ unit: "mm", format: pageSize === "Auto" ? [pw, ph] : pageSize.toLowerCase() as any, orientation: orient, compress: true });
        else pdf.addPage(pageSize === "Auto" ? [pw, ph] : pageSize.toLowerCase() as any, orient);
        const m = 10;
        const availW = pw - m * 2, availH = ph - m * 2;
        const r = img.naturalWidth / img.naturalHeight;
        let dw = availW, dh = availW / r;
        if (fit === "fit" && dh > availH) { dh = availH; dw = availH * r; }
        if (fit === "fill") { const s = Math.max(availW / img.naturalWidth, availH / img.naturalHeight); dw = (img.naturalWidth * s * 25.4) / 96; dh = (img.naturalHeight * s * 25.4) / 96; }
        const dx = (pw - dw) / 2, dy = (ph - dh) / 2;
        (pdf as jsPDF).addImage(img, "JPEG", dx, dy, dw, dh, undefined, "FAST");
        setJob({ cur: idx + 1, total: items.length });
        await new Promise((r) => setTimeout(r, 60));
      }
      const blob = (pdf as jsPDF).output("blob");
      const url = URL.createObjectURL(blob);
      setOut({ url, size: blob.size, pages: items.length });
      try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "images-to-pdf", toolName: "Images to PDF", status: "success", detail: `${items.length} images · ${pageSize} ${orient}`, meta: fmtBytes(blob.size) }); } catch {}
    } finally { setJob(null); }
  };

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-4">
        <div className="flex items-center justify-between">
          <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Pages · {items.length} — drag to reorder</div>
          <label className="pressable cursor-pointer rounded-full bg-[#111111] px-3.5 py-2 text-xs font-extrabold text-white">+ Add<input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} /></label>
        </div>
        {items.length === 0 ? (
          <label className="mt-2 flex cursor-pointer flex-col items-center rounded-2xl border-2 border-dashed border-[#CFCCC0] bg-[#F7F7F4] py-10 text-center hover:border-[#111111]">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#F4D9C6]"><ImagePlus className="h-6 w-6" /></span>
            <span className="mt-2 font-display font-extrabold">Add images</span>
            <span className="text-xs font-medium text-[#707070]">Each image becomes one page, in order</span>
            <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
          </label>
        ) : (
          <div className="mt-2 space-y-2">
            {items.map((it, i) => (
              <div key={it.id} draggable onDragStart={() => setDragId(it.id)} onDragOver={(e) => e.preventDefault()} onDrop={() => {
                if (!dragId || dragId === it.id) return;
                setItems((p) => { const from = p.findIndex((x) => x.id === dragId); const to = p.findIndex((x) => x.id === it.id); if (from < 0 || to < 0) return p; const n = [...p]; const [m] = n.splice(from, 1); n.splice(to, 0, m); return n; });
              }} className="flex cursor-grab items-center gap-3 rounded-2xl bg-[#F7F7F4] p-2.5 active:cursor-grabbing">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#111111] font-display text-xs font-extrabold text-white">{i + 1}</span>
                <img src={it.url} className="h-12 w-12 rounded-xl object-cover" alt="" />
                <div className="min-w-0"><div className="truncate text-[13px] font-extrabold">{it.name}</div><div className="text-[11px] font-semibold text-[#707070] tabular-nums">{it.w}×{it.h}</div></div>
                <div className="ml-auto flex gap-1">
                  <button onClick={() => move(it.id, -1)} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white"><ArrowUp className="h-3.5 w-3.5" /></button>
                  <button onClick={() => move(it.id, 1)} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white"><ArrowDown className="h-3.5 w-3.5" /></button>
                  <button onClick={() => setItems((p) => p.filter((x) => x.id !== it.id))} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white text-red-600"><X className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="grid gap-3 rounded-[24px] border border-[#E8E6E0] bg-white p-4 sm:grid-cols-3">
        <div><div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Page size</div><div className="mt-1.5 flex gap-1.5">{(["Auto", "A4", "Letter"] as const).map((s) => <button key={s} onClick={() => setPageSize(s)} className={`pressable flex-1 rounded-full py-2 text-xs font-extrabold ${pageSize === s ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{s}</button>)}</div></div>
        <div><div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Orientation</div><div className="mt-1.5 flex gap-1.5">{([["portrait", "Portrait"], ["landscape", "Landscape"]] as const).map(([k, l]) => <button key={k} onClick={() => setOrient(k)} className={`pressable flex-1 rounded-full py-2 text-xs font-extrabold ${orient === k ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{l}</button>)}</div></div>
        <div><div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Image fit</div><div className="mt-1.5 flex gap-1.5">{([["fit", "Fit"], ["fill", "Fill"]] as const).map(([k, l]) => <button key={k} onClick={() => setFit(k)} className={`pressable flex-1 rounded-full py-2 text-xs font-extrabold ${fit === k ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{l}</button>)}</div></div>
        <label className="sm:col-span-3"><span className="mb-1 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">File name</span><span className="flex items-center gap-2 rounded-2xl border-[1.5px] border-[#E0DED6] px-4 py-1"><input value={name} onChange={(e) => setName(e.target.value.replace(/[^\w\- ]/g, ""))} className="w-full bg-transparent py-2 text-sm font-bold outline-none" /><span className="text-xs font-extrabold text-[#707070]">.pdf</span></span></label>
      </div>
      <ActionBar primary={items.length ? `Create PDF (${items.length} pages)` : "Add images first"} onPrimary={create} secondary={[{ label: "Clear", onClick: () => { setItems([]); setOut(null); } }, { label: "Back", onClick: onBack }]} />
      {out && (
        <div className="space-y-2 pop-in">
          <ResultCard title="PDF ready" tint="#F4D9C6" icon={<FileText className="h-5 w-5" />} rows={[["Pages", `${out.pages}`], ["Size", fmtBytes(out.size)], ["Layout", `${pageSize} ${orient}`], ["Engine", "Local"]]} />
          <button onClick={() => downloadUrl(out.url, `${name || "document"}.pdf`)} className="pressable flex w-full items-center justify-center gap-2 rounded-2xl bg-[#111111] py-4 font-display text-[15px] font-extrabold text-white"><Download className="h-4 w-4" /> Download PDF</button>
        </div>
      )}
      {job && <ProcessingOverlay tool="Images to PDF" current={job.cur} total={job.total} label="Laying out pages…" onCancel={() => { cancelRef.current = true; }} />}
    </div>
  );
}

// ─── PDF TO IMAGES ───
export function PdfToImages({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "pdf-to-images")!;
  const [file, setFile] = useState<{ f: File; url: string } | null>(null);
  const [pages, setPages] = useState(0);
  const [range, setRange] = useState("1-3");
  const [fmt, setFmt] = useState<"jpeg" | "png">("jpeg");
  const [scale, setScale] = useState(2);
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [outs, setOuts] = useState<{ name: string; url: string; size: number; thumb: string }[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const cancelRef = useRef(false);
  useEffect(() => { touchRecent("pdf-to-images"); }, []);

  const pick = async (f: File | undefined) => {
    if (!f) return;
    setErr(null); setOuts([]);
    const url = URL.createObjectURL(f);
    setFile({ f, url });
    try {
      const pdfjs = await getPdfJs();
      const buf = await f.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf }).promise;
      setPages(doc.numPages);
      setRange(`1-${Math.min(doc.numPages, 5)}`);
      await doc.destroy();
    } catch { setErr("That PDF could not be read (CORRUPT_FILE or protected)."); }
  };

  const parseRange = (total: number): number[] => {
    const set = new Set<number>();
    range.split(",").forEach((part) => {
      const p = part.trim();
      if (/^\d+$/.test(p)) { const n = +p; if (n >= 1 && n <= total) set.add(n); }
      else if (/^(\d+)\s*-\s*(\d+)$/.test(p)) {
        const [, a, b] = p.match(/^(\d+)\s*-\s*(\d+)$/)!;
        let x = +a, y = +b;
        if (x > y) [x, y] = [y, x];
        for (let n = Math.max(1, x); n <= Math.min(total, y); n++) set.add(n);
        if (set.size > 20) return;
      }
    });
    return [...set].sort((a, b) => a - b).slice(0, 20);
  };

  const convert = async () => {
    if (!file) return;
    setErr(null);
    const wanted = parseRange(pages);
    if (!wanted.length) { setErr("Enter a valid page range, e.g. 1-3 or 1,4,6."); return; }
    cancelRef.current = false;
    setJob({ cur: 0, total: wanted.length });
    setOuts([]);
    try {
      const pdfjs = await getPdfJs();
      const buf = await file.f.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf }).promise;
      const results: typeof outs = [];
      for (let i = 0; i < wanted.length; i++) {
        if (cancelRef.current) break;
        const n = wanted[i];
        const page = await doc.getPage(n);
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement("canvas");
        canvas.width = Math.min(viewport.width, 2600);
        canvas.height = Math.min(viewport.height, 3400);
        const ctx = canvas.getContext("2d")!;
        if (fmt === "jpeg") { ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height); }
        await page.render({ canvasContext: ctx, viewport: page.getViewport({ scale: (canvas.width / viewport.width) * scale }) }).promise;
        const blob: Blob = await new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error())), fmt === "png" ? "image/png" : "image/jpeg", 0.92));
        results.push({ name: `${file.f.name.replace(/\.pdf$/i, "")}-p${n}.${fmt === "png" ? "png" : "jpg"}`, url: URL.createObjectURL(blob), size: blob.size, thumb: canvas.toDataURL("image/jpeg", 0.5) });
        setOuts([...results]);
        setJob({ cur: i + 1, total: wanted.length });
      }
      await doc.destroy();
      if (!cancelRef.current && results.length) {
        try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "pdf-to-images", toolName: "PDF to Images", status: "success", detail: `${results.length} pages → ${fmt.toUpperCase()}`, meta: file.f.name }); } catch {}
      }
    } catch { setErr("Rendering failed on this device (MEMORY_GUARD). Try fewer pages or lower quality."); }
    setJob(null);
  };

  const zipAll = async () => {
    const zip = new JSZip();
    for (const o of outs) {
      const b = await (await fetch(o.url)).blob();
      zip.file(o.name, b);
    }
    const blob = await zip.generateAsync({ type: "blob" });
    downloadUrl(URL.createObjectURL(blob), "qwiktools-pages.zip");
  };

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      {!file ? (
        <label className="flex cursor-pointer flex-col items-center rounded-[28px] bg-[#111111] px-6 py-12 text-center text-white hover:bg-black">
          <span className="grid h-16 w-16 place-items-center rounded-[22px] bg-[#E8D8F6] text-[#111111]"><FileImage className="h-7 w-7" /></span>
          <span className="mt-4 font-display text-xl font-extrabold">Choose a PDF</span>
          <span className="mt-1 text-[13px] font-medium text-white/60">Rendered page-by-page, on this device</span>
          <span className="pressable mt-5 rounded-2xl bg-white px-6 py-3 text-sm font-extrabold text-[#111111]">Browse files</span>
          <input type="file" accept="application/pdf" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
      ) : (
        <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#E8D8F6]"><FileText className="h-5 w-5" /></span>
            <div className="min-w-0"><div className="truncate text-sm font-extrabold">{file.f.name}</div><div className="text-xs font-semibold text-[#707070] tabular-nums">{pages} pages · {fmtBytes(file.f.size)}</div></div>
            <button onClick={() => { setFile(null); setOuts([]); }} className="pressable ml-auto grid h-9 w-9 place-items-center rounded-full bg-[#F4F3EE]"><X className="h-4 w-4" /></button>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <label className="block"><span className="mb-1 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Pages (max 20)</span><input value={range} onChange={(e) => setRange(e.target.value)} placeholder="1-3" className="w-full rounded-2xl border-[1.5px] border-[#E0DED6] px-4 py-2.5 font-mono text-sm font-bold outline-none focus:border-[#111111]" /></label>
            <div><span className="mb-1 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Format</span><div className="flex gap-1.5">{([["jpeg", "JPG"], ["png", "PNG"]] as const).map(([k, l]) => <button key={k} onClick={() => setFmt(k)} className={`pressable flex-1 rounded-full py-2.5 text-xs font-extrabold ${fmt === k ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{l}</button>)}</div></div>
            <div><span className="mb-1 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Quality · {scale}x</span><div className="flex gap-1.5">{[1, 2, 3].map((s) => <button key={s} onClick={() => setScale(s)} className={`pressable flex-1 rounded-full py-2.5 text-xs font-extrabold ${scale === s ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{s}x</button>)}</div></div>
          </div>
          <p className="mt-2 text-[11px] font-semibold text-[#707070]">Tip: 1x is fastest, 2x is crisp for most documents, 3x is print-grade but heavier.</p>
        </div>
      )}
      {err && <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] font-semibold text-red-700">{err}</div>}
      <ActionBar primary={file ? `Convert ${parseRange(pages).length || "…"} pages` : "Choose a PDF first"} onPrimary={convert} secondary={[{ label: "Pick another", onClick: () => (document.querySelector<HTMLInputElement>("#pdfpick")?.click()) }, { label: "Back", onClick: onBack }]} />
      <input id="pdfpick" type="file" accept="application/pdf" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
      {outs.length > 0 && (
        <div className="space-y-2 pop-in">
          <div className="flex items-center justify-between">
            <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Rendered · {outs.length}</div>
            {outs.length > 1 && <button onClick={zipAll} className="pressable rounded-full bg-[#111111] px-4 py-2 text-xs font-extrabold text-white">Download .zip</button>}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {outs.map((o) => (
              <div key={o.name} className="overflow-hidden rounded-2xl border border-[#E8E6E0] bg-white">
                <img src={o.thumb} className="aspect-[3/4] w-full object-cover" alt="" loading="lazy" />
                <div className="flex items-center gap-1 p-2">
                  <span className="truncate text-[11px] font-extrabold">{o.name}</span>
                  <button onClick={() => downloadUrl(o.url, o.name)} className="pressable ml-auto grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#111111] text-white"><Download className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {job && <ProcessingOverlay tool="PDF to Images" current={job.cur} total={job.total} label="Rendering pages…" onCancel={() => { cancelRef.current = true; }} />}
    </div>
  );
}

// ─── PDF MERGE ───
interface MPdf { id: string; name: string; size: number; buf: ArrayBuffer; pages: number; }
export function PdfMerge({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "pdf-merge")!;
  const [items, setItems] = useState<MPdf[]>([]);
  const [name, setName] = useState("merged-document");
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [out, setOut] = useState<{ url: string; size: number; pages: number } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const cancelRef = useRef(false);
  useEffect(() => { touchRecent("pdf-merge"); }, []);

  const add = async (fl: FileList | null) => {
    if (!fl) return;
    setErr(null);
    const arr = Array.from(fl).filter((f) => f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf"));
    for (const f of arr) {
      try {
        const buf = await f.arrayBuffer();
        const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
        setItems((p) => [...p, { id: uid(), name: f.name, size: f.size, buf, pages: doc.getPageCount() }]);
      } catch { setErr(`“${f.name}” could not be read — it may be encrypted or corrupt.`); }
    }
    setOut(null);
  };
  const move = (id: string, dir: -1 | 1) => {
    setItems((p) => {
      const i = p.findIndex((x) => x.id === id); const j = i + dir;
      if (i < 0 || j < 0 || j >= p.length) return p;
      const n = [...p]; [n[i], n[j]] = [n[j], n[i]]; return n;
    });
  };

  const merge = async () => {
    if (items.length < 2) { setErr("Add at least 2 PDFs to merge."); return; }
    cancelRef.current = false;
    setJob({ cur: 0, total: items.length });
    setErr(null);
    try {
      const merged = await PDFDocument.create();
      let totalPages = 0;
      for (let i = 0; i < items.length; i++) {
        if (cancelRef.current) return;
        const src = await PDFDocument.load(items[i].buf);
        const pages = await merged.copyPages(src, src.getPageIndices());
        pages.forEach((p) => merged.addPage(p));
        totalPages += pages.length;
        setJob({ cur: i + 1, total: items.length });
        await new Promise((r) => setTimeout(r, 80));
      }
      const bytes = await merged.save();
      const blob = new Blob([bytes as any], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      setOut({ url, size: blob.size, pages: totalPages });
      try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "pdf-merge", toolName: "PDF Merge", status: "success", detail: `${items.length} files → ${totalPages} pages`, meta: fmtBytes(blob.size) }); } catch {}
    } catch { setErr("Merge failed — one of the files may be protected (EXPORT_FAILED)."); }
    finally { setJob(null); }
  };

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="rounded-[24px] bg-[#111111] p-4 text-white">
        <div className="flex items-center justify-between">
          <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50">Queue · {items.length} files</div>
          <label className="pressable cursor-pointer rounded-full bg-white px-3.5 py-2 text-xs font-extrabold text-[#111111]">+ Add PDFs<input type="file" accept="application/pdf" multiple className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} /></label>
        </div>
        {items.length === 0 ? (
          <label className="mt-3 flex cursor-pointer flex-col items-center rounded-2xl border-2 border-dashed border-white/20 py-10 text-center hover:border-white/50">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#CDEFE6] text-[#111111]"><Combine className="h-6 w-6" /></span>
            <span className="mt-2 font-display font-extrabold">Drop PDFs here</span>
            <span className="text-xs font-medium text-white/50">They join in the order shown below</span>
            <input type="file" accept="application/pdf" multiple className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
          </label>
        ) : (
          <div className="mt-3 space-y-2">
            {items.map((it, i) => (
              <div key={it.id} className="flex items-center gap-3 rounded-2xl bg-white/10 p-2.5 ring-1 ring-white/10">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#CDEFE6] font-display text-xs font-extrabold text-[#111111]">{i + 1}</span>
                <div className="min-w-0"><div className="truncate text-[13px] font-extrabold">{it.name}</div><div className="text-[11px] font-semibold text-white/50 tabular-nums">{it.pages} pages · {fmtBytes(it.size)}</div></div>
                <div className="ml-auto flex gap-1">
                  <button onClick={() => move(it.id, -1)} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white/15"><ArrowUp className="h-3.5 w-3.5" /></button>
                  <button onClick={() => move(it.id, 1)} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white/15"><ArrowDown className="h-3.5 w-3.5" /></button>
                  <button onClick={() => setItems((p) => p.filter((x) => x.id !== it.id))} className="pressable grid h-8 w-8 place-items-center rounded-full bg-white/15 text-red-300"><X className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            ))}
            <label className="mt-1 block"><span className="mb-1 block text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50">Output name</span><span className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 ring-1 ring-white/15"><input value={name} onChange={(e) => setName(e.target.value.replace(/[^\w\- ]/g, ""))} className="w-full bg-transparent py-2.5 text-sm font-bold outline-none placeholder:text-white/30" placeholder="merged-document" /><span className="text-xs font-extrabold text-white/40">.pdf</span></span></label>
          </div>
        )}
      </div>
      {err && <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] font-semibold text-red-700">{err}</div>}
      <ActionBar primary={items.length >= 2 ? `Merge ${items.length} PDFs` : "Add at least 2 PDFs"} onPrimary={merge} secondary={[{ label: "Clear", onClick: () => { setItems([]); setOut(null); } }, { label: "Back", onClick: onBack }]} />
      {out && (
        <div className="space-y-2 pop-in">
          <ResultCard title="Merged PDF" tint="#CDEFE6" icon={<Eye className="h-5 w-5" />} rows={[["Pages", `${out.pages}`], ["Size", fmtBytes(out.size)], ["Files", `${items.length}`], ["Engine", "Local"]]} />
          <button onClick={() => downloadUrl(out.url, `${name || "merged"}.pdf`)} className="pressable flex w-full items-center justify-center gap-2 rounded-2xl bg-[#111111] py-4 font-display text-[15px] font-extrabold text-white"><Download className="h-4 w-4" /> Download merged PDF</button>
        </div>
      )}
      {job && <ProcessingOverlay tool="PDF Merge" current={job.cur} total={job.total} label="Stitching documents…" onCancel={() => { cancelRef.current = true; }} />}
    </div>
  );
}
