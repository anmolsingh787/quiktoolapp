import { useEffect, useMemo, useRef, useState } from "react";
import { ImagePlus, X, Download, Trash2, Eye, ArrowRight, AlertTriangle, Check, Share2 } from "lucide-react";
import { downloadUrl, fmtBytes, loadSettings, pushHistory, touchRecent, uid } from "../lib/core";
import { ActionBar, OfflineBadge, ProcessingOverlay, ResultCard, ToolHeader } from "../components/chrome";
import { TOOLS } from "../lib/core";

interface ImgItem { id: string; file: File; url: string; w: number; h: number; size: number; name: string; }

async function fileToItem(f: File): Promise<ImgItem> {
  const url = URL.createObjectURL(f);
  const dims = await new Promise<{ w: number; h: number }>((res) => {
    const img = new Image();
    img.onload = () => res({ w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => res({ w: 0, h: 0 });
    img.src = url;
  });
  return { id: uid(), file: f, url, w: dims.w, h: dims.h, size: f.size, name: f.name };
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
}

async function renderCompressed(img: HTMLImageElement, quality: number, maxDim: number | null, outType: string): Promise<Blob> {
  let { naturalWidth: w, naturalHeight: h } = img;
  if (maxDim && Math.max(w, h) > maxDim) {
    const s = maxDim / Math.max(w, h);
    w = Math.round(w * s); h = Math.round(h * s);
  }
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  if (outType === "image/jpeg") { ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, w, h); }
  ctx.drawImage(img, 0, 0, w, h);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error("encode"))), outType, quality));
}

function PickStrip({ items, onAdd, onRemove, accent = "#E8D8F6" }: { items: ImgItem[]; onAdd: (f: FileList | null) => void; onRemove: (id: string) => void; accent?: string }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Selected · {items.length}</div>
        <label className="pressable cursor-pointer rounded-full bg-[#111111] px-3.5 py-2 text-xs font-extrabold text-white">+ Add<input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { onAdd(e.target.files); e.target.value = ""; }} /></label>
      </div>
      {items.length === 0 ? (
        <label className="mt-2 flex cursor-pointer flex-col items-center justify-center rounded-[24px] border-2 border-dashed border-[#CFCCC0] bg-white/70 px-6 py-10 text-center hover:border-[#111111]">
          <span className="grid h-14 w-14 place-items-center rounded-2xl" style={{ background: accent }}><ImagePlus className="h-6 w-6" /></span>
          <span className="mt-3 font-display text-[15px] font-extrabold">Choose images</span>
          <span className="text-xs font-medium text-[#707070]">Tap to browse — files never leave this device</span>
          <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { onAdd(e.target.files); e.target.value = ""; }} />
        </label>
      ) : (
        <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto pb-1">
          {items.map((it) => (
            <div key={it.id} className="relative w-24 shrink-0 overflow-hidden rounded-2xl border border-[#E8E6E0] bg-white">
              <img src={it.url} className="aspect-square w-full object-cover" alt="" />
              <button onClick={() => onRemove(it.id)} className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-[#111111] text-white"><X className="h-3.5 w-3.5" /></button>
              <div className="truncate px-1.5 py-1 text-[10px] font-bold text-[#707070]">{fmtBytes(it.size)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── COMPRESSOR ───
export function ImageCompressor({ onBack, onFav, fav }: { onBack: () => void; onFav: () => void; fav: boolean }) {
  const tool = TOOLS.find((t) => t.key === "image-compressor")!;
  const [items, setItems] = useState<ImgItem[]>([]);
  const [preset, setPreset] = useState<"fast" | "auto" | "best">("auto");
  const [quality, setQuality] = useState(loadSettings().quality);
  const [outFmt, setOutFmt] = useState<"keep" | "webp" | "jpeg">("webp");
  const [keepDim, setKeepDim] = useState(true);
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [results, setResults] = useState<{ name: string; url: string; before: number; after: number; type: string }[] | null>(null);
  const cancelRef = useRef(false);

  useEffect(() => { touchRecent("image-compressor"); }, []);
  useEffect(() => { if (preset === "fast") setQuality(55); if (preset === "best") setQuality(92); if (preset === "auto") setQuality(78); }, [preset]);

  const add = async (fl: FileList | null) => {
    if (!fl) return;
    const arr = Array.from(fl).filter((f) => f.type.startsWith("image/")).slice(0, 20 - items.length);
    const mapped = await Promise.all(arr.map(fileToItem));
    setItems((p) => [...p, ...mapped]);
    setResults(null);
  };

  const compress = async () => {
    if (!items.length) return;
    cancelRef.current = false;
    setJob({ cur: 0, total: items.length });
    const out: typeof results = [];
    let before = 0, after = 0;
    for (let i = 0; i < items.length; i++) {
      if (cancelRef.current) break;
      setJob({ cur: i, total: items.length });
      const it = items[i];
      try {
        const img = await loadImage(it.url);
        const fmt = outFmt === "keep" ? (it.file.type.includes("png") ? "image/png" : it.file.type.includes("webp") ? "image/webp" : "image/jpeg") : outFmt === "webp" ? "image/webp" : "image/jpeg";
        const q = fmt === "image/png" ? 1 : quality / 100;
        const blob = await renderCompressed(img, q, keepDim ? null : 1920, fmt);
        const ext = fmt.includes("webp") ? "webp" : fmt.includes("png") ? "png" : "jpg";
        const url = URL.createObjectURL(blob);
        before += it.size; after += blob.size;
        out.push({ name: it.name.replace(/\.\w+$/, "") + `.compressed.${ext}`, url, before: it.size, after: blob.size, type: ext.toUpperCase() });
      } catch {}
      await new Promise((r) => setTimeout(r, 120));
      setJob({ cur: i + 1, total: items.length });
    }
    setJob(null);
    if (!cancelRef.current && out.length) {
      setResults(out);
      try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "image-compressor", toolName: "Image Compressor", status: "success", detail: `${out.length} image${out.length > 1 ? "s" : ""} · Q${quality}`, meta: `${fmtBytes(before)} → ${fmtBytes(after)}` }); } catch {}
    }
  };

  const saved = useMemo(() => {
    if (!results) return null;
    const b = results.reduce((a, r) => a + r.before, 0), a = results.reduce((a, r) => a + r.after, 0);
    return { b, a, pct: b ? Math.max(0, Math.round((1 - a / b) * 100)) : 0 };
  }, [results]);

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <PickStrip items={items} onAdd={add} onRemove={(id) => setItems((p) => p.filter((x) => x.id !== id))} accent="#E8D8F6" />
      <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-5">
        <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Quality preset</div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {[["fast", "Fast", "Smaller"], ["auto", "Auto", "Balanced"], ["best", "Best", "Sharper"]].map(([k, a, b]) => (
            <button key={k} onClick={() => setPreset(k as any)} className={`pressable rounded-2xl border-2 px-3 py-3 text-center ${preset === k ? "border-[#111111] bg-[#111111] text-white" : "border-[#EFEDE6] bg-[#F7F7F4]"}`}>
              <div className="text-[13px] font-extrabold">{a}</div><div className={`text-[11px] font-semibold ${preset === k ? "text-white/60" : "text-[#707070]"}`}>{b}</div>
            </button>
          ))}
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-xs font-extrabold"><span>Compression quality</span><span className="rounded-full bg-[#E8D8F6] px-2.5 py-0.5 tabular-nums">{quality}%</span></div>
          <input type="range" min={10} max={100} value={quality} onChange={(e) => { setQuality(+e.target.value); setPreset("auto"); }} className="qwik-range mt-2 w-full" style={{ ["--fill" as any]: `${quality}%` }} />
        </div>
        <div className="mt-4">
          <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Output</div>
          <div className="mt-2 flex gap-2">{[["keep", "Keep"], ["webp", "WebP"], ["jpeg", "JPG"]].map(([k, l]) => <button key={k} onClick={() => setOutFmt(k as any)} className={`pressable rounded-full px-4 py-2 text-xs font-extrabold ${outFmt === k ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{l}</button>)}</div>
        </div>
        <label className="mt-4 flex cursor-pointer items-center justify-between rounded-2xl bg-[#F7F7F4] px-4 py-3">
          <span className="text-[13px] font-extrabold">Keep original dimensions</span>
          <span onClick={() => setKeepDim(!keepDim)} className={`qwik-toggle grid h-7 w-12 place-items-center rounded-full ${keepDim ? "bg-[#111111]" : "bg-[#D8D5CC]"}`}><span className={`h-5 w-5 rounded-full bg-white transition-all ${keepDim ? "translate-x-2.5" : "-translate-x-2.5"}`} /></span>
        </label>
      </div>
      <ActionBar primary={items.length ? `Compress ${items.length} image${items.length > 1 ? "s" : ""}` : "Choose images first"} onPrimary={compress} secondary={[{ label: "Clear", onClick: () => { setItems([]); setResults(null); } }, { label: "★ Favorite", onClick: onFav }]} />
      {results && saved && (
        <div className="space-y-3 pop-in">
          <ResultCard title="Compressed" tint="#E8D8F6" icon={<Check className="h-5 w-5" />} rows={[["Before", fmtBytes(saved.b)], ["After", fmtBytes(saved.a)], ["Saved", `${saved.pct}%`], ["Files", `${results.length}`]]} />
          {results.map((r) => (
            <div key={r.name} className="flex items-center gap-3 rounded-2xl border border-[#E8E6E0] bg-white p-3">
              <img src={r.url} className="h-12 w-12 rounded-xl object-cover" alt="" />
              <div className="min-w-0"><div className="truncate text-[13px] font-extrabold">{r.name}</div><div className="text-[11px] font-semibold text-[#707070] tabular-nums">{fmtBytes(r.before)} → {fmtBytes(r.after)} · {r.type}</div></div>
              <button onClick={() => downloadUrl(r.url, r.name)} className="pressable ml-auto grid h-10 w-10 place-items-center rounded-full bg-[#111111] text-white"><Download className="h-4 w-4" /></button>
            </div>
          ))}
          <button onClick={() => results.forEach((r) => downloadUrl(r.url, r.name))} className="pressable w-full rounded-2xl bg-[#E8D8F6] py-3.5 text-sm font-extrabold">Download all ({results.length})</button>
        </div>
      )}
      {job && <ProcessingOverlay tool="Image Compressor" current={job.cur} total={job.total} label="Compressing on-device…" onCancel={() => { cancelRef.current = true; }} />}
    </div>
  );
}

// ─── RESIZER ───
export function ImageResizer({ onBack, onFav, fav }: { onBack: () => void; onFav: () => void; fav: boolean }) {
  const tool = TOOLS.find((t) => t.key === "image-resizer")!;
  const [items, setItems] = useState<ImgItem[]>([]);
  const [w, setW] = useState(1080);
  const [h, setH] = useState(1080);
  const [lock, setLock] = useState(true);
  const [fmt, setFmt] = useState<"webp" | "jpeg" | "png">("webp");
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [results, setResults] = useState<{ name: string; url: string; dims: string; size: number }[] | null>(null);
  const cancelRef = useRef(false);
  useEffect(() => { touchRecent("image-resizer"); }, []);

  const add = async (fl: FileList | null) => {
    if (!fl) return;
    const arr = Array.from(fl).filter((f) => f.type.startsWith("image/")).slice(0, 20 - items.length);
    const mapped = await Promise.all(arr.map(fileToItem));
    setItems((p) => [...p, ...mapped]);
    if (mapped[0]?.w) { setW(Math.min(mapped[0].w, 1920)); setH(Math.round(mapped[0].h * (Math.min(mapped[0].w, 1920) / mapped[0].w))); }
    setResults(null);
  };

  const applyPreset = (p: number) => {
    const base = items[0];
    if (!base?.w) return;
    setW(Math.round(base.w * p)); setH(Math.round(base.h * p));
  };

  const resize = async () => {
    if (!items.length) return;
    cancelRef.current = false;
    setJob({ cur: 0, total: items.length });
    const out: NonNullable<typeof results> = [];
    for (let i = 0; i < items.length; i++) {
      if (cancelRef.current) break;
      const it = items[i];
      try {
        const img = await loadImage(it.url);
        let tw = w, th = h;
        if (lock && img.naturalWidth && img.naturalHeight) {
          const s = Math.min(tw / img.naturalWidth, th / img.naturalHeight);
          // fit inside box preserving ratio
          tw = Math.max(1, Math.round(img.naturalWidth * s)); th = Math.max(1, Math.round(img.naturalHeight * s));
        }
        const c = document.createElement("canvas");
        c.width = tw; c.height = th;
        const ctx = c.getContext("2d")!;
        if (fmt === "jpeg") { ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, tw, th); }
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(img, 0, 0, tw, th);
        const blob: Blob = await new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error())), fmt === "png" ? "image/png" : fmt === "webp" ? "image/webp" : "image/jpeg", 0.92));
        out.push({ name: it.name.replace(/\.\w+$/, "") + `-${tw}x${th}.${fmt === "jpeg" ? "jpg" : fmt}`, url: URL.createObjectURL(blob), dims: `${tw}×${th}`, size: blob.size });
      } catch {}
      setJob({ cur: i + 1, total: items.length });
      await new Promise((r) => setTimeout(r, 100));
    }
    setJob(null);
    if (!cancelRef.current && out.length) {
      setResults(out);
      try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "image-resizer", toolName: "Image Resizer", status: "success", detail: `${out.length} resized to ${w}×${h}`, meta: fmt.toUpperCase() }); } catch {}
    }
  };

  const num = "w-full rounded-2xl border-[1.5px] border-[#E0DED6] bg-[#F7F7F4] px-4 py-3 font-display text-lg font-extrabold tabular-nums outline-none focus:border-[#111111]";

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <PickStrip items={items} onAdd={add} onRemove={(id) => setItems((p) => p.filter((x) => x.id !== id))} accent="#F4D9C6" />
      <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Target size (px)</div>
          <button onClick={() => setLock(!lock)} className={`pressable rounded-full px-3.5 py-1.5 text-xs font-extrabold ${lock ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{lock ? "⛓ Aspect locked" : "Free aspect"}</button>
        </div>
        <div className="mt-2 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          <div><input type="number" value={w} onChange={(e) => setW(Math.max(1, +e.target.value || 1))} className={num} /><div className="mt-1 text-center text-[11px] font-bold text-[#707070]">WIDTH</div></div>
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#F4D9C6] font-black">×</span>
          <div><input type="number" value={h} onChange={(e) => setH(Math.max(1, +e.target.value || 1))} className={num} /><div className="mt-1 text-center text-[11px] font-bold text-[#707070]">HEIGHT</div></div>
        </div>
        <div className="mt-3 flex gap-2">{[[0.25, "25%"], [0.5, "50%"], [0.75, "75%"], [1, "100%"]].map(([v, l]) => <button key={l as string} onClick={() => applyPreset(v as number)} className="pressable flex-1 rounded-full bg-[#F4F3EE] py-2 text-xs font-extrabold hover:bg-[#F4D9C6]">{l}</button>)}</div>
        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Format</span>
          {[["webp", "WebP"], ["jpeg", "JPG"], ["png", "PNG"]].map(([k, l]) => <button key={k} onClick={() => setFmt(k as any)} className={`pressable rounded-full px-4 py-2 text-xs font-extrabold ${fmt === k ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{l}</button>)}
        </div>
        {items[0] && <p className="mt-3 rounded-2xl bg-[#F7F7F4] px-4 py-2.5 text-xs font-semibold text-[#707070]">Original: <b className="text-[#111] tabular-nums">{items[0].w}×{items[0].h}</b> · Target: <b className="text-[#111] tabular-nums">{w}×{h}</b> {lock && "· ratio preserved (fit inside box)"}</p>}
      </div>
      <ActionBar primary={items.length ? `Resize ${items.length} image${items.length > 1 ? "s" : ""}` : "Choose images first"} onPrimary={resize} secondary={[{ label: "Clear", onClick: () => { setItems([]); setResults(null); } }, { label: "★ Favorite", onClick: onFav }]} />
      {results && (
        <div className="space-y-2 pop-in">
          <ResultCard title="Resized" tint="#F4D9C6" icon={<Eye className="h-5 w-5" />} rows={[["Output", `${w}×${h}`], ["Format", fmt.toUpperCase()], ["Files", `${results.length}`], ["Engine", "Local canvas"]]} />
          {results.map((r) => (
            <div key={r.name} className="flex items-center gap-3 rounded-2xl border border-[#E8E6E0] bg-white p-3">
              <img src={r.url} className="h-12 w-12 rounded-xl object-cover" alt="" />
              <div><div className="truncate text-[13px] font-extrabold">{r.name}</div><div className="text-[11px] font-semibold text-[#707070] tabular-nums">{r.dims} · {fmtBytes(r.size)}</div></div>
              <button onClick={() => downloadUrl(r.url, r.name)} className="pressable ml-auto grid h-10 w-10 place-items-center rounded-full bg-[#111111] text-white"><Download className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
      )}
      {job && <ProcessingOverlay tool="Image Resizer" current={job.cur} total={job.total} label="Resampling pixels…" onCancel={() => { cancelRef.current = true; }} />}
    </div>
  );
}

// ─── CONVERTER ───
export function ImageConverter({ onBack, onFav, fav }: { onBack: () => void; onFav: () => void; fav: boolean }) {
  const tool = TOOLS.find((t) => t.key === "image-converter")!;
  const [items, setItems] = useState<ImgItem[]>([]);
  const [fmt, setFmt] = useState<"jpeg" | "png" | "webp">("webp");
  const [quality, setQuality] = useState(90);
  const [job, setJob] = useState<{ cur: number; total: number } | null>(null);
  const [results, setResults] = useState<{ name: string; url: string; before: number; after: number }[] | null>(null);
  const cancelRef = useRef(false);
  useEffect(() => { touchRecent("image-converter"); }, []);

  const add = async (fl: FileList | null) => {
    if (!fl) return;
    const arr = Array.from(fl).filter((f) => f.type.startsWith("image/")).slice(0, 20 - items.length);
    const mapped = await Promise.all(arr.map(fileToItem));
    setItems((p) => [...p, ...mapped]);
    setResults(null);
  };

  const convert = async () => {
    if (!items.length) return;
    cancelRef.current = false;
    setJob({ cur: 0, total: items.length });
    const out: NonNullable<typeof results> = [];
    for (let i = 0; i < items.length; i++) {
      if (cancelRef.current) break;
      const it = items[i];
      try {
        const img = await loadImage(it.url);
        const mime = fmt === "png" ? "image/png" : fmt === "webp" ? "image/webp" : "image/jpeg";
        const blob = await renderCompressed(img, fmt === "png" ? 1 : quality / 100, null, mime);
        const ext = fmt === "jpeg" ? "jpg" : fmt;
        out.push({ name: it.name.replace(/\.\w+$/, "") + `.${ext}`, url: URL.createObjectURL(blob), before: it.size, after: blob.size });
      } catch {}
      setJob({ cur: i + 1, total: items.length });
      await new Promise((r) => setTimeout(r, 100));
    }
    setJob(null);
    if (!cancelRef.current && out.length) {
      setResults(out);
      try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "image-converter", toolName: "Format Converter", status: "success", detail: `${out.length} → ${fmt.toUpperCase()}`, meta: `Q${quality}` }); } catch {}
    }
  };

  const hasAlpha = items.some((i) => i.file.type.includes("png") || i.file.type.includes("webp"));

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <PickStrip items={items} onAdd={add} onRemove={(id) => setItems((p) => p.filter((x) => x.id !== id))} accent="#CDEFE6" />
      <div className="rounded-[24px] bg-[#111111] p-5 text-white">
        <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50">Convert to</div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {[["jpeg", "JPG", "Photos"], ["png", "PNG", "Lossless"], ["webp", "WebP", "Modern"]].map(([k, a, b]) => (
            <button key={k} onClick={() => setFmt(k as any)} className={`pressable rounded-2xl p-3.5 text-center transition ${fmt === k ? "bg-[#CDEFE6] text-[#111111]" : "bg-white/10 text-white hover:bg-white/15"}`}>
              <div className="font-display text-[16px] font-extrabold">{a}</div><div className={`text-[11px] font-semibold ${fmt === k ? "text-[#111111]/60" : "text-white/50"}`}>{b}</div>
            </button>
          ))}
        </div>
        {fmt !== "png" && (
          <div className="mt-4">
            <div className="flex justify-between text-xs font-extrabold"><span>Quality</span><span className="tabular-nums">{quality}%</span></div>
            <input type="range" min={10} max={100} value={quality} onChange={(e) => setQuality(+e.target.value)} className="qwik-range mt-2 w-full !bg-none" style={{ background: `linear-gradient(to right, #CDEFE6 ${quality}%, rgba(255,255,255,0.15) ${quality}%)`, ["--fill" as any]: `${quality}%` }} />
          </div>
        )}
      </div>
      {fmt === "jpeg" && hasAlpha && (
        <div className="flex gap-2.5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-[13px] font-semibold text-amber-800"><AlertTriangle className="h-4 w-4 shrink-0" /> JPG has no transparency — transparent areas become white.</div>
      )}
      <ActionBar primary={items.length ? `Convert to ${fmt.toUpperCase()} ${ArrowRight ? "" : ""}` : "Choose images first"} onPrimary={convert} secondary={[{ label: "Clear", onClick: () => { setItems([]); setResults(null); } }, { label: "★ Favorite", onClick: onFav }]} />
      {results && (
        <div className="space-y-2 pop-in">
          <ResultCard title={`Converted to ${fmt.toUpperCase()}`} tint="#CDEFE6" icon={<Check className="h-5 w-5" />} rows={[["Files", `${results.length}`], ["Total in", fmtBytes(results.reduce((a, r) => a + r.before, 0))], ["Total out", fmtBytes(results.reduce((a, r) => a + r.after, 0))], ["Quality", fmt === "png" ? "Lossless" : `${quality}%`]]} />
          {results.map((r) => (
            <div key={r.name} className="flex items-center gap-3 rounded-2xl border border-[#E8E6E0] bg-white p-3">
              <img src={r.url} className="h-12 w-12 rounded-xl object-cover" alt="" />
              <div className="min-w-0"><div className="truncate text-[13px] font-extrabold">{r.name}</div><div className="text-[11px] font-semibold text-[#707070] tabular-nums">{fmtBytes(r.before)} → {fmtBytes(r.after)}</div></div>
              <div className="ml-auto flex gap-1.5">
                <button onClick={() => { if (navigator.share) { fetch(r.url).then((x) => x.blob()).then((b) => (navigator as any).share({ files: [new File([b], r.name, { type: "image/*" })] }).catch(() => {})); } }} className="pressable grid h-10 w-10 place-items-center rounded-full bg-[#F4F3EE]"><Share2 className="h-4 w-4" /></button>
                <button onClick={() => downloadUrl(r.url, r.name)} className="pressable grid h-10 w-10 place-items-center rounded-full bg-[#111111] text-white"><Download className="h-4 w-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {job && <ProcessingOverlay tool="Format Converter" current={job.cur} total={job.total} label={`Encoding ${fmt.toUpperCase()}…`} onCancel={() => { cancelRef.current = true; }} />}
      {void fav}
      {void Trash2}
    </div>
  );
}
