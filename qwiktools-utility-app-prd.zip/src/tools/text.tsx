import { useEffect, useMemo, useState } from "react";
import { Copy, Check, RefreshCw, Eye, EyeOff, Eraser, ClipboardPaste, Share2, ShieldCheck, AlertTriangle } from "lucide-react";
import { touchRecent } from "../lib/core";
import { OfflineBadge, ToolHeader } from "../components/chrome";
import { TOOLS } from "../lib/core";

// ─── PASSWORD ───
const SETS = { upper: "ABCDEFGHJKLMNPQRSTUVWXYZ", lower: "abcdefghijkmnopqrstuvwxyz", nums: "23456789", sym: "!@#$%^&*()-_=+[]{};:,.<>?" };
const AMBIG = /[Il1O0|`'"_;:,.]/g;

function genPass(len: number, use: Record<string, boolean>, exclAmb: boolean) {
  const cryptoObj = window.crypto;
  let pool = "";
  if (use.upper) pool += SETS.upper;
  if (use.lower) pool += SETS.lower;
  if (use.nums) pool += SETS.nums;
  if (use.sym) pool += SETS.sym;
  if (!pool) pool = SETS.lower;
  if (exclAmb) pool = pool.replace(AMBIG, "");
  const arr = new Uint32Array(len);
  cryptoObj.getRandomValues(arr);
  let out = "";
  for (let i = 0; i < len; i++) out += pool[arr[i] % pool.length];
  // guarantee at least one of each enabled class
  const classes = Object.entries(use).filter(([, v]) => v).map(([k]) => k as keyof typeof SETS);
  if (classes.length > 1 && len >= classes.length) {
    const chars = out.split("");
    classes.forEach((c, i) => {
      let p = SETS[c];
      if (exclAmb) p = p.replace(AMBIG, "");
      if (p) chars[i * Math.floor(len / classes.length)] = p[arr[i] % p.length];
    });
    out = chars.join("");
  }
  return out;
}

function strength(pw: string, use: Record<string, boolean>) {
  let pool = 0;
  if (use.upper) pool += 24; if (use.lower) pool += 24; if (use.nums) pool += 8; if (use.sym) pool += 22;
  if (!pool) pool = 24;
  const bits = pw.length * Math.log2(pool);
  if (bits < 40) return { label: "Weak", pct: 22, color: "#e0655a" };
  if (bits < 60) return { label: "Fair", pct: 45, color: "#e0a53c" };
  if (bits < 80) return { label: "Strong", pct: 72, color: "#3f9e6e" };
  return { label: "Elite", pct: 100, color: "#111111" };
}

export function PasswordGen({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "password")!;
  const [len, setLen] = useState(16);
  const [use, setUse] = useState({ upper: true, lower: true, nums: true, sym: true });
  const [exclAmb, setExclAmb] = useState(true);
  const [pw, setPw] = useState(() => genPass(16, { upper: true, lower: true, nums: true, sym: true }, true));
  const [show, setShow] = useState(true);
  const [copied, setCopied] = useState(false);
  useEffect(() => { touchRecent("password"); }, []);
  const s = useMemo(() => strength(pw, use), [pw, use]);
  const regen = () => setPw(genPass(len, use, exclAmb));
  useEffect(() => { regen(); // eslint-disable-next-line
  }, [len]);

  const toggleRow = (label: string, desc: string, on: boolean, fn: () => void, sample: string) => (
    <button onClick={fn} className="flex w-full items-center gap-3 rounded-2xl bg-[#F7F7F4] px-4 py-3 text-left pressable">
      <span className="font-mono text-xs font-bold text-[#707070] w-14">{sample}</span>
      <span><span className="block text-[13px] font-extrabold">{label}</span><span className="block text-[11px] font-medium text-[#707070]">{desc}</span></span>
      <span className={`ml-auto grid h-7 w-12 shrink-0 place-items-center rounded-full transition ${on ? "bg-[#111111]" : "bg-[#D8D5CC]"}`}><span className={`h-5 w-5 rounded-full bg-white transition-all ${on ? "translate-x-2.5" : "-translate-x-2.5"}`} /></span>
    </button>
  );

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="rounded-[28px] bg-[#111111] p-6 text-white">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50"><ShieldCheck className="h-3.5 w-3.5 text-[#CDEFE6]" /> Generated on-device</span>
          <button onClick={() => setShow(!show)} className="pressable grid h-9 w-9 place-items-center rounded-full bg-white/10">{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
        </div>
        <div className="mt-3 break-all rounded-2xl bg-white/[0.07] p-5 text-center font-mono text-[19px] font-bold leading-relaxed ring-1 ring-white/10" style={{ filter: show ? "none" : "blur(7px)", userSelect: "all" }}>{pw}</div>
        <div className="mt-3 flex items-center gap-2">
          <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${s.pct}%`, background: s.color === "#111111" ? "#CDEFE6" : s.color }} /></div>
          <span className="rounded-full bg-white/10 px-3 py-1 text-[11px] font-extrabold">{s.label}</span>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={() => { navigator.clipboard?.writeText(pw); setCopied(true); setTimeout(() => setCopied(false), 1400); }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-[#CDEFE6] py-3.5 text-sm font-extrabold text-[#111111]">{copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}{copied ? "Copied" : "Copy"}</button>
          <button onClick={regen} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white py-3.5 text-sm font-extrabold text-[#111111]"><RefreshCw className="h-4 w-4" /> Regenerate</button>
        </div>
      </div>
      <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-4">
        <div className="flex justify-between text-xs font-extrabold"><span className="uppercase tracking-wider text-[#707070]">Length</span><span className="rounded-full bg-[#111111] px-2.5 py-0.5 text-white tabular-nums">{len}</span></div>
        <input type="range" min={6} max={64} value={len} onChange={(e) => setLen(+e.target.value)} className="qwik-range mt-2 w-full" style={{ ["--fill" as any]: `${((len - 6) / 58) * 100}%` }} />
        <div className="mt-1 flex justify-between text-[11px] font-bold text-[#8A877D]"><span>6 · PIN</span><span>16 · Recommended</span><span>64 · Maximum</span></div>
        <div className="mt-3 space-y-2">
          {toggleRow("Uppercase", "A–Z without I, O", use.upper, () => { const n = { ...use, upper: !use.upper }; setUse(n); setPw(genPass(len, n, exclAmb)); }, "ABC")}
          {toggleRow("Lowercase", "a–z without l", use.lower, () => { const n = { ...use, lower: !use.lower }; setUse(n); setPw(genPass(len, n, exclAmb)); }, "abc")}
          {toggleRow("Numbers", "2–9 without 0, 1", use.nums, () => { const n = { ...use, nums: !use.nums }; setUse(n); setPw(genPass(len, n, exclAmb)); }, "123")}
          {toggleRow("Symbols", "!@#… 22 safe marks", use.sym, () => { const n = { ...use, sym: !use.sym }; setUse(n); setPw(genPass(len, n, exclAmb)); }, "#&?")}
          {toggleRow("No look-alikes", "Excludes Il1O0 etc.", exclAmb, () => { setExclAmb(!exclAmb); setPw(genPass(len, use, !exclAmb)); }, "aØ")}
        </div>
      </div>
      <div className="flex gap-2.5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-[12.5px] font-semibold text-amber-800"><AlertTriangle className="h-4 w-4 shrink-0" /> Passwords are never saved to history. Copy it to your password manager now.</div>
    </div>
  );
}

// ─── WORD COUNTER ───
export function WordCounter({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "word-counter")!;
  const [text, setText] = useState("QwikTools is a fast, private, offline-first utility app.\n\nPaste anything here — essays, captions, emails — and watch live stats update as you type. Nothing ever leaves this device.");
  const [copied, setCopied] = useState(false);
  useEffect(() => { touchRecent("word-counter"); }, []);

  const stats = useMemo(() => {
    const chars = text.length;
    const noSpaces = text.replace(/\s/g, "").length;
    const words = (text.trim().match(/\S+/g) || []).length;
    const lines = text === "" ? 0 : text.split("\n").length;
    const paras = (text.split(/\n\s*\n/).filter((p) => p.trim().length > 0)).length;
    const sentences = (text.match(/[.!?]+(\s|$)/g) || []).length;
    const readMin = words / 200;
    const read = readMin < 1 ? `${Math.max(1, Math.round(readMin * 60))} sec` : `${readMin.toFixed(1)} min`;
    const unique = new Set((text.toLowerCase().match(/[a-z0-9']+/g) || [])).size;
    return { chars, noSpaces, words, lines, paras: text.trim() ? paras : 0, sentences, read, unique };
  }, [text]);

  const cards: [string, string, string][] = [
    ["Words", `${stats.words}`, "#111111"],
    ["Characters", `${stats.chars}`, "#CDEFE6"],
    ["No spaces", `${stats.noSpaces}`, "#E8D8F6"],
    ["Sentences", `${stats.sentences}`, "#F4D9C6"],
    ["Lines", `${stats.lines}`, "#FDF6E9"],
    ["Paragraphs", `${stats.paras}`, "#CDEFE6"],
  ];

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
        {cards.map(([k, v, tint]) => (
          <div key={k} className="rounded-2xl border border-[#E8E6E0] bg-white p-3 text-center" style={tint === "#111111" ? { background: "#111111", color: "#fff", borderColor: "#111111" } : {}}>
            <div className="font-display text-xl font-extrabold tabular-nums">{v}</div>
            <div className={`text-[10px] font-extrabold uppercase tracking-wider ${tint === "#111111" ? "text-white/60" : "text-[#707070]"}`}>{k}</div>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <span className="rounded-full bg-white px-3 py-1.5 text-xs font-extrabold border border-[#E8E6E0]">📖 {stats.read} read</span>
        <span className="rounded-full bg-white px-3 py-1.5 text-xs font-extrabold border border-[#E8E6E0]">✨ {stats.unique} unique words</span>
        <span className="rounded-full bg-[#CDEFE6] px-3 py-1.5 text-xs font-extrabold">Live · offline</span>
      </div>
      <div className="overflow-hidden rounded-[24px] border border-[#E8E6E0] bg-white">
        <div className="flex items-center gap-2 border-b border-[#F0EEE8] px-4 py-2.5">
          <span className="flex gap-1.5"><i className="h-2.5 w-2.5 rounded-full bg-[#F4D9C6] block" /><i className="h-2.5 w-2.5 rounded-full bg-[#E8D8F6] block" /><i className="h-2.5 w-2.5 rounded-full bg-[#CDEFE6] block" /></span>
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#707070]">Editor</span>
          <span className="ml-auto text-[11px] font-bold tabular-nums text-[#8A877D]">{stats.words} words</span>
        </div>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} placeholder="Type or paste text here…" className="w-full resize-y bg-transparent px-5 py-4 text-[15px] font-medium leading-relaxed outline-none placeholder:text-[#B9B6AC]" />
        <div className="grid grid-cols-4 gap-2 border-t border-[#F0EEE8] p-3">
          <button onClick={async () => { try { setText(await navigator.clipboard.readText()); } catch {} }} className="pressable flex items-center justify-center gap-1.5 rounded-xl bg-[#F4F3EE] py-2.5 text-xs font-extrabold"><ClipboardPaste className="h-3.5 w-3.5" /> Paste</button>
          <button onClick={() => { navigator.clipboard?.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1400); }} className="pressable flex items-center justify-center gap-1.5 rounded-xl bg-[#F4F3EE] py-2.5 text-xs font-extrabold">{copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}{copied ? "Copied" : "Copy"}</button>
          <button onClick={() => { if (navigator.share) navigator.share({ text }).catch(() => {}); }} className="pressable flex items-center justify-center gap-1.5 rounded-xl bg-[#F4F3EE] py-2.5 text-xs font-extrabold"><Share2 className="h-3.5 w-3.5" /> Share</button>
          <button onClick={() => setText("")} className="pressable flex items-center justify-center gap-1.5 rounded-xl bg-[#111111] py-2.5 text-xs font-extrabold text-white"><Eraser className="h-3.5 w-3.5" /> Clear</button>
        </div>
      </div>
    </div>
  );
}
