import { useEffect, useRef, useState } from "react";
import { Camera, ImagePlus, Flashlight, FlashlightOff, Copy, Share2, Check, ExternalLink, RotateCcw, Star, Download, Pencil, Plus, Wifi, Globe, MessageSquare, User, FileText } from "lucide-react";
import QRCode from "qrcode";
import jsQR from "jsqr";
import { detectQrKind, downloadUrl, loadSettings, pushHistory, touchRecent } from "../lib/core";
import { ActionBar, OfflineBadge, ProcessingOverlay, ResultCard, ToolHeader } from "../components/chrome";
import { TOOLS } from "../lib/core";

// ─── QR SCANNER ───
export function QrScanner({ onBack, onFav, fav }: { onBack: () => void; onFav: () => void; fav: boolean }) {
  const tool = TOOLS.find((t) => t.key === "qr-scanner")!;
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const [mode, setMode] = useState<"idle" | "camera" | "result">("idle");
  const [error, setError] = useState<string | null>(null);
  const [torch, setTorch] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [scanning, setScanning] = useState(false);

  const stop = () => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setScanning(false);
  };
  useEffect(() => () => stop(), []);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setMode("camera");
      setScanning(true);
      tick();
      touchRecent("qr-scanner");
    } catch {
      setError("CAMERA_UNAVAILABLE — camera blocked or missing. You can still scan an image from your gallery below.");
    }
  };

  const tick = () => {
    const video = videoRef.current, canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(tick);
      return;
    }
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    try {
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(data.data, data.width, data.height, { inversionAttempts: "attemptBoth" });
      if (code?.data) {
        handleFound(code.data);
        return;
      }
    } catch {}
    rafRef.current = requestAnimationFrame(tick);
  };

  const handleFound = (text: string) => {
    stop();
    setResult(text);
    setMode("result");
    try {
      if (loadSettings().historyEnabled) pushHistory({ featureKey: "qr-scanner", toolName: "QR Scanner", status: "success", detail: text.slice(0, 90) || "QR code", meta: detectQrKind(text).label });
    } catch {}
  };

  const scanFile = (f: File) => {
    setError(null);
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = img.naturalWidth; c.height = img.naturalHeight;
      const ctx = c.getContext("2d", { willReadFrequently: true });
      if (!ctx) { setError("Could not read that image."); return; }
      ctx.drawImage(img, 0, 0);
      try {
        const d = ctx.getImageData(0, 0, c.width, c.height);
        const code = jsQR(d.data, d.width, d.height, { inversionAttempts: "attemptBoth" });
        if (code?.data) handleFound(code.data);
        else setError("No QR code found in that image. Try a sharper, well-lit photo.");
      } catch { setError("That file could not be decoded (UNSUPPORTED_FORMAT)."); }
      URL.revokeObjectURL(url);
    };
    img.onerror = () => setError("That file is not a readable image (CORRUPT_FILE).");
    img.src = url;
  };

  const toggleTorch = async () => {
    try {
      const track = streamRef.current?.getVideoTracks()[0] as any;
      await track?.applyConstraints({ advanced: [{ torch: !torch }] });
      setTorch(!torch);
    } catch {}
  };

  const kind = result ? detectQrKind(result) : null;

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<span className="flex items-center gap-2"><OfflineBadge /><button onClick={onFav} className={`grid h-10 w-10 place-items-center rounded-full pressable ${fav ? "bg-[#111111] text-[#F4D9C6]" : "bg-white border border-[#E0DED6]"}`}><Star className={`h-4 w-4 ${fav ? "fill-current" : ""}`} /></button></span>} />

      {mode !== "result" ? (
        <>
          <div className="relative overflow-hidden rounded-[28px] bg-[#111111] text-white">
            {mode === "camera" ? (
              <div className="relative">
                <video ref={videoRef} playsInline muted className="aspect-[4/4.4] w-full object-cover" />
                <canvas ref={canvasRef} className="hidden" />
                <div className="pointer-events-none absolute inset-6 rounded-[24px] border-2 border-white/70">
                  <span className="absolute -left-0.5 -top-0.5 h-8 w-8 rounded-tl-[22px] border-l-4 border-t-4 border-[#CDEFE6]" />
                  <span className="absolute -right-0.5 -top-0.5 h-8 w-8 rounded-tr-[22px] border-r-4 border-t-4 border-[#CDEFE6]" />
                  <span className="absolute -bottom-0.5 -left-0.5 h-8 w-8 rounded-bl-[22px] border-b-4 border-l-4 border-[#CDEFE6]" />
                  <span className="absolute -bottom-0.5 -right-0.5 h-8 w-8 rounded-br-[22px] border-b-4 border-r-4 border-[#CDEFE6]" />
                  <span className="absolute inset-x-8 h-0.5 rounded-full bg-[#CDEFE6] shadow-[0_0_18px_#CDEFE6]" style={{ animation: "scan-line 2.2s ease-in-out infinite" }} />
                </div>
                <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4">
                  <button onClick={() => { stop(); setMode("idle"); }} className="pressable rounded-full bg-white/15 px-4 py-2 text-xs font-extrabold backdrop-blur">Close</button>
                  <button onClick={toggleTorch} className="pressable grid h-10 w-10 place-items-center rounded-full bg-white/15 backdrop-blur">{torch ? <FlashlightOff className="h-4 w-4" /> : <Flashlight className="h-4 w-4" />}</button>
                </div>
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-5 pt-10 text-center">
                  <p className="text-[13px] font-bold text-white/90">{scanning ? "Point at a QR code — it scans automatically" : "Starting camera…"}</p>
                </div>
              </div>
            ) : (
              <div className="p-6 sm:p-8">
                <video ref={videoRef} className="hidden" />
                <canvas ref={canvasRef} className="hidden" />
                <div className="mx-auto grid h-20 w-20 place-items-center rounded-[26px] bg-white/10"><Camera className="h-9 w-9 text-[#CDEFE6]" /></div>
                <h2 className="mt-4 text-center font-display text-[22px] font-extrabold tracking-tight">Scan any QR code</h2>
                <p className="mx-auto mt-1 max-w-[34ch] text-center text-[13px] font-medium text-white/60">Camera stays on-device. Nothing is uploaded — decoding happens right here.</p>
                <div className="mt-5 grid gap-2 sm:grid-cols-2">
                  <button onClick={startCamera} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-[#CDEFE6] py-4 text-sm font-extrabold text-[#111111]"><Camera className="h-4 w-4" /> Open camera</button>
                  <label className="pressable flex cursor-pointer items-center justify-center gap-2 rounded-2xl bg-white/10 py-4 text-sm font-extrabold ring-1 ring-white/25">
                    <ImagePlus className="h-4 w-4" /> From gallery
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) scanFile(f); e.target.value = ""; }} />
                  </label>
                </div>
                <div className="mt-4 flex items-center justify-center gap-2 text-[11px] font-bold text-white/50">
                  <span className="rounded-full bg-white/10 px-2.5 py-1">URL</span><span className="rounded-full bg-white/10 px-2.5 py-1">Wi-Fi</span><span className="rounded-full bg-white/10 px-2.5 py-1">Contact</span><span className="rounded-full bg-white/10 px-2.5 py-1">Text</span>
                </div>
              </div>
            )}
          </div>
          {error && <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] font-semibold text-red-700">{error}</div>}
          <div className="grid grid-cols-3 gap-2">
            {[["Auto-detect", "Links, Wi-Fi, mail"], ["Torch", "Low-light toggle"], ["Private", "Zero uploads"]].map(([a, b]) => (
              <div key={a} className="rounded-2xl bg-white p-3 text-center border border-[#E8E6E0]"><div className="text-[12px] font-extrabold">{a}</div><div className="text-[11px] font-medium text-[#707070]">{b}</div></div>
            ))}
          </div>
        </>
      ) : (
        <div className="space-y-3 pop-in">
          <div className="overflow-hidden rounded-[28px] bg-[#111111] p-6 text-white">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-[#CDEFE6] px-3 py-1 text-[11px] font-extrabold text-[#111111]">{kind?.label}</span>
              <span className="ml-auto flex items-center gap-1 text-[11px] font-bold text-white/50"><Check className="h-3.5 w-3.5 text-emerald-300" /> Decoded locally</span>
            </div>
            <p className="mt-4 break-all font-mono text-[15px] font-semibold leading-relaxed">{result}</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => { navigator.clipboard?.writeText(result || ""); setCopied(true); setTimeout(() => setCopied(false), 1600); }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white py-3.5 text-sm font-extrabold border border-[#E0DED6]">{copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}{copied ? "Copied" : "Copy"}</button>
            <button onClick={() => { if (navigator.share) navigator.share({ text: result || "" }).catch(() => {}); else { navigator.clipboard?.writeText(result || ""); } }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white py-3.5 text-sm font-extrabold border border-[#E0DED6]"><Share2 className="h-4 w-4" /> Share</button>
            {kind?.kind === "url" && <button onClick={() => window.open(result!, "_blank", "noopener")} className="pressable col-span-2 flex items-center justify-center gap-2 rounded-2xl bg-[#CDEFE6] py-4 text-sm font-extrabold"><ExternalLink className="h-4 w-4" /> Open link</button>}
            {kind?.kind === "wifi" && <WifiInfo payload={result!} />}
          </div>
          <ActionBar primary="Scan again" onPrimary={() => { setResult(null); setMode("idle"); }} secondary={[{ label: "Back home", onClick: onBack }, { label: "Copy payload", onClick: () => navigator.clipboard?.writeText(result || "") }]} />
          <button onClick={() => { setResult(null); setMode("idle"); }} className="mx-auto flex items-center gap-1.5 text-xs font-extrabold text-[#707070]"><RotateCcw className="h-3.5 w-3.5" /> New scan</button>
        </div>
      )}
    </div>
  );
}

function WifiInfo({ payload }: { payload: string }) {
  const m = payload.match(/S:([^;]+);.*P:([^;]*);/);
  return (
    <div className="col-span-2 rounded-2xl bg-[#F4D9C6] p-4 text-sm">
      <div className="font-extrabold">Wi-Fi detected</div>
      <div className="mt-1 font-medium text-[#111111]/70">Network: <b>{m?.[1] || "hidden"}</b>{m?.[2] ? <> · Password: <b className="font-mono">{m[2]}</b></> : " · Open network"}</div>
    </div>
  );
}

// ─── QR GENERATOR ───
type QrType = "website" | "text" | "wifi" | "contact" | "whatsapp";
export function QrGenerator({ onBack, onFav, fav }: { onBack: () => void; onFav: () => void; fav: boolean }) {
  const tool = TOOLS.find((t) => t.key === "qr-generator")!;
  const [type, setType] = useState<QrType>("website");
  const [website, setWebsite] = useState("https://qwiktools.app");
  const [text, setText] = useState("Hello from QwikTools — fast, private, offline.");
  const [ssid, setSsid] = useState("HomeWiFi");
  const [pass, setPass] = useState("");
  const [enc, setEnc] = useState("WPA");
  const [name, setName] = useState("Ada Lovelace");
  const [phone, setPhone] = useState("+15551234567");
  const [email, setEmail] = useState("ada@example.com");
  const [wa, setWa] = useState("+15551234567");
  const [waMsg, setWaMsg] = useState("Hi! Found you via QR.");
  const [fg, setFg] = useState("#111111");
  const [bg, setBg] = useState("#ffffff");
  const [margin, setMargin] = useState(2);
  const [dataUrl, setDataUrl] = useState("");
  const [busy, setBusy] = useState(false);

  const payload = (() => {
    switch (type) {
      case "website": return website.trim() || "https://qwiktools.app";
      case "text": return text || " ";
      case "wifi": return `WIFI:T:${enc};S:${ssid};;P:${pass};;`;
      case "contact": return `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL:${phone}\nEMAIL:${email}\nEND:VCARD`;
      case "whatsapp": return `https://wa.me/${wa.replace(/\D/g, "")}?text=${encodeURIComponent(waMsg)}`;
    }
  })();

  useEffect(() => {
    touchRecent("qr-generator");
  }, []);
  useEffect(() => {
    let alive = true;
    setBusy(true);
    const t = setTimeout(async () => {
      try {
        const url = await QRCode.toDataURL(payload, { width: 640, margin, color: { dark: fg, light: bg }, errorCorrectionLevel: "M" });
        if (alive) setDataUrl(url);
      } catch {}
      if (alive) setBusy(false);
    }, 220);
    return () => { alive = false; clearTimeout(t); };
  }, [payload, fg, bg, margin]);

  const save = () => {
    if (!dataUrl) return;
    downloadUrl(dataUrl, `qwiktools-qr-${type}.png`);
    try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "qr-generator", toolName: "QR Generator", status: "success", detail: `${type} · ${payload.slice(0, 70)}`, meta: "PNG · 640px" }); } catch {}
  };

  const tabs: { k: QrType; label: string; icon: React.ReactNode }[] = [
    { k: "website", label: "Website", icon: <Globe className="h-4 w-4" /> },
    { k: "text", label: "Text", icon: <FileText className="h-4 w-4" /> },
    { k: "wifi", label: "Wi-Fi", icon: <Wifi className="h-4 w-4" /> },
    { k: "contact", label: "Contact", icon: <User className="h-4 w-4" /> },
    { k: "whatsapp", label: "WhatsApp", icon: <MessageSquare className="h-4 w-4" /> },
  ];

  const field = "w-full rounded-2xl border-[1.5px] border-[#E0DED6] bg-white px-4 py-3 text-sm font-semibold outline-none focus:border-[#111111] placeholder:text-[#B9B6AC]";

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<span className="flex items-center gap-2"><OfflineBadge /><button onClick={onFav} className={`grid h-10 w-10 place-items-center rounded-full pressable ${fav ? "bg-[#111111] text-[#F4D9C6]" : "bg-white border border-[#E0DED6]"}`}><Star className={`h-4 w-4 ${fav ? "fill-current" : ""}`} /></button></span>} />
      <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
        {tabs.map((t) => (
          <button key={t.k} onClick={() => setType(t.k)} className={`pressable flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2.5 text-[13px] font-extrabold ${type === t.k ? "bg-[#111111] text-white" : "bg-white text-[#5b594f]"}`}>{t.icon}{t.label}</button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-5">
          {type === "website" && (<label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Website URL</span><input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://…" className={field} /></label>)}
          {type === "text" && (<label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Any text</span><textarea value={text} onChange={(e) => setText(e.target.value)} rows={4} className={`${field} resize-none`} /></label>)}
          {type === "wifi" && (<div className="grid gap-3 sm:grid-cols-2"><label className="block sm:col-span-1"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Network name</span><input value={ssid} onChange={(e) => setSsid(e.target.value)} className={field} /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Password</span><input value={pass} onChange={(e) => setPass(e.target.value)} className={field} /></label><div className="sm:col-span-2 flex gap-2">{["WPA", "WEP", "nopass"].map((e) => <button key={e} onClick={() => setEnc(e)} className={`pressable rounded-full px-4 py-2 text-xs font-extrabold ${enc === e ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{e === "nopass" ? "Open" : e}</button>)}</div></div>)}
          {type === "contact" && (<div className="grid gap-3"><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Full name</span><input value={name} onChange={(e) => setName(e.target.value)} className={field} /></label><div className="grid gap-3 sm:grid-cols-2"><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Phone</span><input value={phone} onChange={(e) => setPhone(e.target.value)} className={field} /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Email</span><input value={email} onChange={(e) => setEmail(e.target.value)} className={field} /></label></div></div>)}
          {type === "whatsapp" && (<div className="grid gap-3"><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">WhatsApp number</span><input value={wa} onChange={(e) => setWa(e.target.value)} className={field} /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-[#707070]">Prefilled message</span><input value={waMsg} onChange={(e) => setWaMsg(e.target.value)} className={field} /></label></div>)}

          <div className="mt-5 border-t border-dashed border-[#E0DED6] pt-4">
            <div className="mb-2 text-xs font-extrabold uppercase tracking-wider text-[#707070]">Style · preview updates live</div>
            <div className="flex flex-wrap items-center gap-3">
              {[["Ink", "#111111", "#ffffff"], ["Mint", "#0f3d33", "#CDEFE6"], ["Plum", "#3d2358", "#E8D8F6"], ["Clay", "#5b2f16", "#F4D9C6"]].map(([label, f, b]) => (
                <button key={label} onClick={() => { setFg(f); setBg(b); }} className={`pressable flex items-center gap-2 rounded-full border-2 px-3 py-2 text-xs font-extrabold ${fg === f ? "border-[#111111]" : "border-transparent bg-[#F4F3EE]"}`}>
                  <span className="grid h-6 w-6 place-items-center rounded-md text-[8px] font-black" style={{ background: b, color: f, border: `1.5px solid ${f}` }}>QR</span>{label}
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-3 items-center gap-3">
              <label className="flex items-center gap-2 text-xs font-bold">Dot <input type="color" value={fg} onChange={(e) => setFg(e.target.value)} className="h-8 w-10 cursor-pointer rounded-lg border border-[#E0DED6]" /></label>
              <label className="flex items-center gap-2 text-xs font-bold">Paper <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-8 w-10 cursor-pointer rounded-lg border border-[#E0DED6]" /></label>
              <label className="text-xs font-bold">Quiet zone: <b>{margin}</b><input type="range" min={0} max={5} value={margin} onChange={(e) => setMargin(+e.target.value)} className="qwik-range mt-1 w-full" style={{ ["--fill" as any]: `${(margin / 5) * 100}%` }} /></label>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="rounded-[24px] bg-[#111111] p-5 text-center text-white">
            <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50">Live preview · PNG 640px</div>
            <div className="mx-auto mt-3 grid aspect-square w-full max-w-[260px] place-items-center overflow-hidden rounded-2xl bg-white p-3">
              {dataUrl ? <img src={dataUrl} alt="QR preview" className="h-full w-full object-contain" /> : <span className="text-xs font-bold text-[#8A877D]">Generating…</span>}
            </div>
            <p className="mx-auto mt-3 max-w-[26ch] break-all font-mono text-[11px] text-white/60">{payload.slice(0, 90)}{payload.length > 90 ? "…" : ""}</p>
          </div>
          <button onClick={save} disabled={!dataUrl || busy} className="pressable flex w-full items-center justify-center gap-2 rounded-2xl bg-[#111111] py-4 font-display text-[15px] font-extrabold text-white disabled:opacity-50 border border-[#111111]"><Download className="h-4 w-4" /> {busy ? "Rendering…" : "Save PNG"}</button>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => { if (navigator.share && dataUrl) { fetch(dataUrl).then((r) => r.blob()).then((b) => { const f = new File([b], "qr.png", { type: "image/png" }); (navigator as any).share?.({ files: [f] }).catch(() => {}); }); } }} className="pressable rounded-2xl border-[1.5px] border-[#E0DED6] bg-white py-3 text-[13px] font-extrabold">Share</button>
            <button onClick={() => { setWebsite("https://"); setText(""); setPass(""); }} className="pressable flex items-center justify-center gap-1.5 rounded-2xl border-[1.5px] border-[#E0DED6] bg-white py-3 text-[13px] font-extrabold"><Pencil className="h-3.5 w-3.5" /> Reset</button>
          </div>
          <ResultCard title="Export ready" tint="#CDEFE6" icon={<Plus className="h-5 w-5" />} rows={[["Format", "PNG"], ["Size", "640 × 640"], ["Correction", "M · 15%"], ["Cost", "Free · offline"]]} />
        </div>
      </div>
    </div>
  );
}
