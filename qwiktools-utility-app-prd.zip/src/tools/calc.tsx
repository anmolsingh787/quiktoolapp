import { useEffect, useMemo, useState } from "react";
import { Copy, Check, ArrowLeftRight, RotateCcw } from "lucide-react";
import { pushHistory, loadSettings, touchRecent } from "../lib/core";
import { OfflineBadge, ToolHeader } from "../components/chrome";
import { TOOLS } from "../lib/core";

// ─── PERCENTAGE ───
export function PercentageCalc({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "percentage")!;
  const [mode, setMode] = useState<0 | 1 | 2>(0);
  const [a, setA] = useState("25");
  const [b, setB] = useState("200");
  const [copied, setCopied] = useState(false);
  useEffect(() => { touchRecent("percentage"); }, []);

  const result = useMemo(() => {
    const x = parseFloat(a), y = parseFloat(b);
    if (isNaN(x) || isNaN(y)) return null;
    if (mode === 0) return { main: ((x / 100) * y).toLocaleString(undefined, { maximumFractionDigits: 4 }), sub: `${x}% of ${y}`, formula: `(${x} ÷ 100) × ${y}` };
    if (mode === 1) {
      if (y === 0) return null;
      return { main: `${((x / y) * 100).toLocaleString(undefined, { maximumFractionDigits: 4 })}%`, sub: `${x} is what % of ${y}`, formula: `(${x} ÷ ${y}) × 100` };
    }
    if (y === 0) return null;
    const d = ((x - y) / Math.abs(y)) * 100;
    return { main: `${d >= 0 ? "+" : ""}${d.toLocaleString(undefined, { maximumFractionDigits: 4 })}%`, sub: `change from ${y} to ${x}`, formula: `((${x} − ${y}) ÷ ${y}) × 100`, up: d >= 0 };
  }, [a, b, mode]);

  const modes = [["X% of Y", "Discounts, tips"], ["X is what % of Y", "Scores, share"], ["% change", "Growth, loss"]] as const;
  const labels = mode === 0 ? ["Percent (%)", "Value (Y)"] : mode === 1 ? ["Part (X)", "Whole (Y)"] : ["New (X)", "Old (Y)"];

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="grid grid-cols-3 gap-2">
        {modes.map(([label, sub], i) => (
          <button key={label} onClick={() => setMode(i as any)} className={`pressable rounded-2xl border-2 p-3 text-center ${mode === i ? "border-[#111111] bg-[#111111] text-white" : "border-[#EFEDE6] bg-white"}`}>
            <div className="text-[12.5px] font-extrabold leading-tight">{label}</div>
            <div className={`mt-0.5 text-[11px] font-medium ${mode === i ? "text-white/60" : "text-[#707070]"}`}>{sub}</div>
          </button>
        ))}
      </div>
      <div className="rounded-[28px] bg-[#111111] p-6 text-white">
        <div className="grid grid-cols-2 gap-3">
          {[a, b].map((v, i) => (
            <label key={i} className="block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.12em] text-white/50">{labels[i]}</span>
              <input value={v} onChange={(e) => (i === 0 ? setA(e.target.value.replace(/[^0-9.\-]/g, "")) : setB(e.target.value.replace(/[^0-9.\-]/g, "")))} inputMode="decimal" className="w-full rounded-2xl bg-white/10 px-4 py-3.5 font-display text-xl font-extrabold tabular-nums outline-none ring-1 ring-white/15 focus:bg-white/15 focus:ring-[#CDEFE6]" placeholder="0" />
            </label>
          ))}
        </div>
        <div className="mt-5 rounded-2xl bg-white/[0.07] p-5 text-center ring-1 ring-white/10">
          <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-[#CDEFE6]">{result?.sub || "Enter numbers"}</div>
          <div className={`mt-1 font-display text-[42px] font-extrabold leading-none tracking-tight tabular-nums ${mode === 2 && result ? (result.up ? "text-[#CDEFE6]" : "text-[#F4D9C6]") : ""}`}>{result?.main ?? "—"}</div>
          {result && <div className="mt-2 font-mono text-[11px] text-white/40">{result.formula}</div>}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={() => { if (result) { navigator.clipboard?.writeText(result.main); setCopied(true); setTimeout(() => setCopied(false), 1400); try { if (loadSettings().historyEnabled) pushHistory({ featureKey: "percentage", toolName: "Percentage", status: "success", detail: `${result.sub} = ${result.main}` }); } catch {} } }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-[#CDEFE6] py-3.5 text-sm font-extrabold text-[#111111]">{copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}{copied ? "Copied" : "Copy result"}</button>
          <button onClick={() => { setA(""); setB(""); }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white/10 py-3.5 text-sm font-extrabold ring-1 ring-white/15"><RotateCcw className="h-4 w-4" /> Reset</button>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[["Tip 15%", () => { setMode(0); setA("15"); }], ["Sale −30%", () => { setMode(2); }], ["Score %", () => { setMode(1); }]].map(([l, fn]) => (
          <button key={l as string} onClick={fn as any} className="pressable rounded-2xl border border-[#E8E6E0] bg-white py-3 text-xs font-extrabold hover:border-[#111111]">{l as string}</button>
        ))}
      </div>
    </div>
  );
}

// ─── UNIT CONVERTER ───
type Cat = "length" | "weight" | "temp" | "area" | "speed" | "data";
const UNITS: Record<Cat, { label: string; units: { k: string; label: string; toBase: (v: number) => number; fromBase: (v: number) => number }[] }> = {
  length: { label: "Length", units: [
    { k: "mm", label: "Millimetres", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
    { k: "cm", label: "Centimetres", toBase: (v) => v / 100, fromBase: (v) => v * 100 },
    { k: "m", label: "Metres", toBase: (v) => v, fromBase: (v) => v },
    { k: "km", label: "Kilometres", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
    { k: "in", label: "Inches", toBase: (v) => v * 0.0254, fromBase: (v) => v / 0.0254 },
    { k: "ft", label: "Feet", toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
    { k: "yd", label: "Yards", toBase: (v) => v * 0.9144, fromBase: (v) => v / 0.9144 },
    { k: "mi", label: "Miles", toBase: (v) => v * 1609.344, fromBase: (v) => v / 1609.344 },
  ]},
  weight: { label: "Weight", units: [
    { k: "g", label: "Grams", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
    { k: "kg", label: "Kilograms", toBase: (v) => v, fromBase: (v) => v },
    { k: "oz", label: "Ounces", toBase: (v) => v * 0.0283495, fromBase: (v) => v / 0.0283495 },
    { k: "lb", label: "Pounds", toBase: (v) => v * 0.453592, fromBase: (v) => v / 0.453592 },
    { k: "t", label: "Tonnes", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
  ]},
  temp: { label: "Temperature", units: [
    { k: "c", label: "Celsius °C", toBase: (v) => v, fromBase: (v) => v },
    { k: "f", label: "Fahrenheit °F", toBase: (v) => ((v - 32) * 5) / 9, fromBase: (v) => (v * 9) / 5 + 32 },
    { k: "k", label: "Kelvin K", toBase: (v) => v - 273.15, fromBase: (v) => v + 273.15 },
  ]},
  area: { label: "Area", units: [
    { k: "m2", label: "Sq metres", toBase: (v) => v, fromBase: (v) => v },
    { k: "km2", label: "Sq kilometres", toBase: (v) => v * 1e6, fromBase: (v) => v / 1e6 },
    { k: "ft2", label: "Sq feet", toBase: (v) => v * 0.092903, fromBase: (v) => v / 0.092903 },
    { k: "ac", label: "Acres", toBase: (v) => v * 4046.86, fromBase: (v) => v / 4046.86 },
    { k: "ha", label: "Hectares", toBase: (v) => v * 10000, fromBase: (v) => v / 10000 },
  ]},
  speed: { label: "Speed", units: [
    { k: "ms", label: "m/s", toBase: (v) => v, fromBase: (v) => v },
    { k: "kmh", label: "km/h", toBase: (v) => v / 3.6, fromBase: (v) => v * 3.6 },
    { k: "mph", label: "mph", toBase: (v) => v * 0.44704, fromBase: (v) => v / 0.44704 },
    { k: "kn", label: "Knots", toBase: (v) => v * 0.514444, fromBase: (v) => v / 0.514444 },
  ]},
  data: { label: "Data", units: [
    { k: "b", label: "Bytes", toBase: (v) => v, fromBase: (v) => v },
    { k: "kb", label: "Kilobytes", toBase: (v) => v * 1024, fromBase: (v) => v / 1024 },
    { k: "mb", label: "Megabytes", toBase: (v) => v * 1024 ** 2, fromBase: (v) => v / 1024 ** 2 },
    { k: "gb", label: "Gigabytes", toBase: (v) => v * 1024 ** 3, fromBase: (v) => v / 1024 ** 3 },
    { k: "tb", label: "Terabytes", toBase: (v) => v * 1024 ** 4, fromBase: (v) => v / 1024 ** 4 },
  ]},
};

export function UnitConverter({ onBack }: { onBack: () => void }) {
  const tool = TOOLS.find((t) => t.key === "unit-converter")!;
  const [cat, setCat] = useState<Cat>("length");
  const [from, setFrom] = useState("m");
  const [to, setTo] = useState("ft");
  const [val, setVal] = useState("10");
  const [copied, setCopied] = useState(false);
  useEffect(() => { touchRecent("unit-converter"); }, []);
  useEffect(() => {
    const u = UNITS[cat].units;
    setFrom(u[0].k); setTo(u[Math.min(1, u.length - 1)].k);
  }, [cat ]);

  const out = useMemo(() => {
    const v = parseFloat(val);
    if (isNaN(v)) return null;
    const U = UNITS[cat].units;
    const f = U.find((x) => x.k === from)!; const t = U.find((x) => x.k === to)!;
    const base = f.toBase(v);
    const r = t.fromBase(base);
    return r.toLocaleString(undefined, { maximumFractionDigits: 6 });
  }, [val, from, to, cat]);

  const swap = () => { setFrom(to); setTo(from); };
  const sel = "w-full appearance-none rounded-2xl border-[1.5px] border-[#E0DED6] bg-white px-4 py-3 text-sm font-extrabold outline-none focus:border-[#111111]";

  return (
    <div className="space-y-4">
      <ToolHeader tool={tool} onBack={onBack} right={<OfflineBadge />} />
      <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
        {(Object.keys(UNITS) as Cat[]).map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`pressable shrink-0 rounded-full px-4 py-2.5 text-[13px] font-extrabold ${cat === c ? "bg-[#111111] text-white" : "bg-white"}`}>{UNITS[c].label}</button>
        ))}
      </div>
      <div className="overflow-hidden rounded-[28px] bg-[#CDEFE6] p-5">
        <label className="block">
          <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#111111]/60">Amount</span>
          <input value={val} onChange={(e) => setVal(e.target.value.replace(/[^0-9.\-]/g, ""))} inputMode="decimal" className="w-full rounded-2xl bg-white px-5 py-4 font-display text-[28px] font-extrabold tabular-nums outline-none focus:ring-2 focus:ring-[#111111]" placeholder="0" />
        </label>
        <div className="mt-3 grid grid-cols-[1fr_auto_1fr] items-end gap-2">
          <label className="block"><span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-[#111111]/60">From</span><select value={from} onChange={(e) => setFrom(e.target.value)} className={sel}>{UNITS[cat].units.map((u) => <option key={u.k} value={u.k}>{u.label}</option>)}</select></label>
          <button onClick={swap} className="pressable mb-0.5 grid h-12 w-12 place-items-center rounded-full bg-[#111111] text-white"><ArrowLeftRight className="h-5 w-5" /></button>
          <label className="block"><span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-[#111111]/60">To</span><select value={to} onChange={(e) => setTo(e.target.value)} className={sel}>{UNITS[cat].units.map((u) => <option key={u.k} value={u.k}>{u.label}</option>)}</select></label>
        </div>
      </div>
      <div className="rounded-[28px] bg-[#111111] p-6 text-center text-white">
        <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/50">Result · offline math</div>
        <div className="mt-1 break-all font-display text-[40px] font-extrabold leading-tight tabular-nums">{out ?? "—"}</div>
        <div className="mt-1 text-[13px] font-bold text-white/50">{val || "0"} {from} = {out} {to}</div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={() => { if (out) { navigator.clipboard?.writeText(`${out} ${to}`); setCopied(true); setTimeout(() => setCopied(false), 1400); } }} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white py-3.5 text-sm font-extrabold text-[#111111]">{copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}{copied ? "Copied" : "Copy"}</button>
          <button onClick={swap} className="pressable flex items-center justify-center gap-2 rounded-2xl bg-white/10 py-3.5 text-sm font-extrabold ring-1 ring-white/15"><ArrowLeftRight className="h-4 w-4" /> Swap</button>
        </div>
      </div>
      <div className="rounded-[24px] border border-[#E8E6E0] bg-white p-4">
        <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">All {UNITS[cat].label.toLowerCase()} equivalents</div>
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          {UNITS[cat].units.map((u) => {
            const v = parseFloat(val);
            const base = isNaN(v) ? 0 : UNITS[cat].units.find((x) => x.k === from)!.toBase(v);
            const r = u.fromBase(base);
            return <div key={u.k} className={`rounded-xl px-3 py-2 text-xs font-bold tabular-nums ${u.k === to ? "bg-[#111111] text-white" : "bg-[#F7F7F4]"}`}>{r.toLocaleString(undefined, { maximumFractionDigits: 4 })} <span className="opacity-60">{u.k}</span></div>;
          })}
        </div>
      </div>
    </div>
  );
}
