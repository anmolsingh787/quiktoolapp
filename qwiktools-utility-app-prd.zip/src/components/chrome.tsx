import React, { useEffect, useMemo, useState } from "react";
import {
  Search, House, LayoutGrid, History, Crown, Settings, X, Star, ChevronRight,
  QrCode, ScanLine, Minimize2, Scaling, Repeat, FileImage, Layers, Combine,
  Percent, Ruler, KeyRound, Type, Bell, Zap, ShieldCheck, WifiOff, ArrowUpRight,
  Sparkles, ChevronLeft, Trash2, Clock, Flame,
} from "lucide-react";
import { CATEGORIES, TOOLS, loadFavs, loadRecent, loadSearches, pushSearch, tintBg, tintFg, type ToolDef, type ViewKey } from "../lib/core";

export const iconFor = (name: string, cls = "h-5 w-5") => {
  const p = { className: cls, strokeWidth: 2 } as const;
  switch (name) {
    case "scan-line": return <ScanLine {...p} />;
    case "qr-code": return <QrCode {...p} />;
    case "minimize-2": return <Minimize2 {...p} />;
    case "scaling": return <Scaling {...p} />;
    case "repeat": return <Repeat {...p} />;
    case "file-image": return <FileImage {...p} />;
    case "file-stack": return <Layers {...p} />;
    case "combine": return <Combine {...p} />;
    case "percent": return <Percent {...p} />;
    case "ruler": return <Ruler {...p} />;
    case "key-round": return <KeyRound {...p} />;
    case "text": return <Type {...p} />;
    default: return <Zap {...p} />;
  }
};

export function Logo({ light = false, size = 34 }: { light?: boolean; size?: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="grid place-items-center rounded-[11px] bg-[#111111] shrink-0" style={{ width: size, height: size }}>
        <svg viewBox="0 0 32 32" style={{ width: size * 0.62, height: size * 0.62 }}>
          <path d="M7 7h7v7H7zM18 7h7v7h-7zM7 18h7v7H7z" fill="none" stroke="#CDEFE6" strokeWidth="2.6" strokeLinejoin="round" />
          <path d="M18 18h4v4h-4z" fill="#F4D9C6" />
          <path d="M23 23h2v2h-2z" fill="#E8D8F6" />
        </svg>
      </div>
      <div className="leading-none">
        <div className={`font-display font-800 text-[17px] tracking-tight font-extrabold ${light ? "text-white" : "text-[#111111]"}`}>QwikTools</div>
        <div className={`text-[10px] font-semibold tracking-[0.18em] uppercase ${light ? "text-white/50" : "text-[#707070]"}`}>Offline utility</div>
      </div>
    </div>
  );
}

// ─── Processing overlay ───
export function ProcessingOverlay({ tool, current, total, onCancel, label }: { tool: string; current: number; total: number; onCancel: () => void; label?: string }) {
  const pct = total ? Math.round((current / total) * 100) : 0;
  return (
    <div className="fixed inset-0 z-[90] grid place-items-center bg-[#111111]/45 p-4 backdrop-blur-sm fade-in">
      <div className="w-full max-w-sm rounded-[26px] bg-white p-6 sheet-spring shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#111111] text-[#CDEFE6]">
            <Zap className="h-5 w-5 animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#707070]">Processing locally</div>
            <div className="font-display text-lg font-extrabold tracking-tight">{tool}</div>
          </div>
        </div>
        <div className="mt-5 flex items-end justify-between text-sm">
          <span className="font-semibold text-[#707070]">{label || "Working on-device…"}</span>
          <span className="font-display font-extrabold tabular-nums">{current} of {total}</span>
        </div>
        <div className="mt-2 h-3 overflow-hidden rounded-full bg-[#F0EEE8]">
          <div className="h-full rounded-full bg-[#111111] transition-all duration-300" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-2 text-right text-xs font-bold tabular-nums text-[#707070]">{pct}%</div>
        <button onClick={onCancel} className="pressable mt-4 w-full rounded-2xl border-2 border-[#111111] py-3 text-sm font-extrabold hover:bg-[#111111] hover:text-white">
          Cancel
        </button>
        <p className="mt-3 text-center text-[11px] font-medium text-[#707070]">Files never leave this device · safe to cancel anytime</p>
      </div>
    </div>
  );
}

// ─── Result summary ───
export function ResultCard({ title, rows, tint = "#CDEFE6", icon }: { title: string; rows: [string, string][]; tint?: string; icon?: React.ReactNode }) {
  return (
    <div className="overflow-hidden rounded-[24px] border border-[#E8E6E0] bg-white">
      <div className="flex items-center gap-3 px-5 pt-5">
        <div className="grid h-10 w-10 place-items-center rounded-2xl text-[#111111]" style={{ background: tint }}>{icon || <Sparkles className="h-5 w-5" />}</div>
        <div className="font-display text-[17px] font-extrabold tracking-tight">{title}</div>
        <span className="ml-auto rounded-full bg-[#111111] px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-white">Done</span>
      </div>
      <div className="grid grid-cols-2 gap-2.5 p-5">
        {rows.map(([k, v]) => (
          <div key={k} className="rounded-2xl bg-[#F7F7F4] px-4 py-3">
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#707070]">{k}</div>
            <div className="font-display text-[15px] font-extrabold tabular-nums">{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ActionBar({ primary, onPrimary, secondary }: { primary: string; onPrimary: () => void; secondary?: { label: string; onClick: () => void }[] }) {
  return (
    <div className="flex flex-col gap-2">
      <button onClick={onPrimary} className="pressable flex w-full items-center justify-center gap-2 rounded-2xl bg-[#111111] py-4 font-display text-[15px] font-extrabold text-white shadow-[0_10px_24px_-10px_rgba(17,17,17,0.6)] hover:bg-black">
        {primary} <ArrowUpRight className="h-4 w-4" />
      </button>
      {secondary && (
        <div className="grid grid-cols-2 gap-2">
          {secondary.map((s) => (
            <button key={s.label} onClick={s.onClick} className="pressable rounded-2xl border-[1.5px] border-[#E0DED6] bg-white py-3 text-[13px] font-extrabold hover:border-[#111111]">{s.label}</button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Section header for tool screens ───
export function ToolHeader({ tool, onBack, right }: { tool: ToolDef; onBack: () => void; right?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <button onClick={onBack} className="pressable grid h-10 w-10 place-items-center rounded-full border-[1.5px] border-[#111111] bg-white"><ChevronLeft className="h-5 w-5" /></button>
      <div className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: tintBg(tool.tint), color: tintFg(tool.tint) }}>{iconFor(tool.icon)}</div>
      <div className="min-w-0">
        <h1 className="font-display truncate text-[19px] font-extrabold tracking-tight">{tool.name}</h1>
        <p className="truncate text-xs font-medium text-[#707070]">{tool.tagline} · 100% offline</p>
      </div>
      <div className="ml-auto">{right}</div>
    </div>
  );
}

export function OfflineBadge() {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-[#CDEFE6] px-3 py-1.5 text-[11px] font-extrabold text-[#111111]">
      <WifiOff className="h-3 w-3" /> On-device
    </span>
  );
}

// ─── Tool card ───
export function ToolCard({ tool, fav, onOpen, onFav, compact }: { tool: ToolDef; fav: boolean; onOpen: () => void; onFav: () => void; compact?: boolean }) {
  return (
    <button onClick={onOpen} className={`pressable group relative overflow-hidden rounded-[22px] border border-[#E8E6E0] bg-white p-4 text-left hover:border-[#111111] hover:shadow-[0_12px_30px_-14px_rgba(17,17,17,0.35)] ${compact ? "" : ""}`}>
      <div className="flex items-start justify-between">
        <div className="grid h-11 w-11 place-items-center rounded-2xl transition-transform group-hover:scale-105" style={{ background: tintBg(tool.tint), color: tintFg(tool.tint) }}>
          {iconFor(tool.icon)}
        </div>
        <span onClick={(e) => { e.stopPropagation(); onFav(); }} className={`grid h-8 w-8 cursor-pointer place-items-center rounded-full transition ${fav ? "bg-[#111111] text-[#F4D9C6]" : "bg-[#F4F3EE] text-[#B9B6AC] hover:text-[#111111]"}`}>
          <Star className={`h-4 w-4 ${fav ? "fill-current" : ""}`} />
        </span>
      </div>
      <div className="mt-3 font-display text-[15px] font-extrabold tracking-tight leading-tight">{tool.name}</div>
      <div className="mt-0.5 line-clamp-1 text-xs font-medium text-[#707070]">{tool.tagline}</div>
    </button>
  );
}

// ─── Search overlay ───
export function SearchOverlay({ open, onClose, onOpenTool }: { open: boolean; onClose: () => void; onOpenTool: (key: string) => void }) {
  const [q, setQ] = useState("");
  const [favs, setFavs] = useState<string[]>(loadFavs());
  const [recent, setRecent] = useState<string[]>(loadRecent());
  const [searches, setSearches] = useState<string[]>(loadSearches());
  useEffect(() => {
    if (open) { setFavs(loadFavs()); setRecent(loadRecent()); setSearches(loadSearches()); setQ(""); }
  }, [open ]);
  const results = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return [];
    return TOOLS.filter((t) => t.name.toLowerCase().includes(needle) || t.tagline.toLowerCase().includes(needle) || t.keywords.some((k) => k.includes(needle) || needle.includes(k))).slice(0, 8);
  }, [q]);
  if (!open) return null;
  const favTools = TOOLS.filter((t) => favs.includes(t.key));
  const recentTools = recent.map((k) => TOOLS.find((t) => t.key === k)).filter(Boolean) as ToolDef[];
  const go = (key: string) => { if (q.trim()) { pushSearch(q); } onOpenTool(key); };
  return (
    <div className="fixed inset-0 z-[80] bg-[#111111]/45 backdrop-blur-sm fade-in" onClick={onClose}>
      <div className="mx-auto mt-[6vh] w-[calc(100%-2rem)] max-w-xl overflow-hidden rounded-[26px] bg-[#F7F7F4] shadow-2xl sheet-spring" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 border-b border-[#E8E6E0] bg-white p-3">
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-[#F4F3EE] px-4 py-3">
            <Search className="h-4 w-4 text-[#707070]" />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && results[0]) go(results[0].key); }} placeholder="Search tools — try “compress”…" className="w-full bg-transparent text-sm font-semibold outline-none placeholder:text-[#A9A69B]" />
            {q && <button onClick={() => setQ("")}><X className="h-4 w-4 text-[#707070]" /></button>}
          </div>
          <button onClick={onClose} className="pressable rounded-2xl bg-[#111111] px-4 py-3 text-sm font-extrabold text-white">Done</button>
        </div>
        <div className="max-h-[60vh] overflow-y-auto p-4">
          {q.trim() === "" ? (
            <div className="space-y-5">
              {searches.length > 0 && (
                <div>
                  <div className="mb-2 flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#707070]"><Clock className="h-3.5 w-3.5" /> Recent searches</div>
                  <div className="flex flex-wrap gap-2">
                    {searches.map((s) => <button key={s} onClick={() => setQ(s)} className="pressable rounded-full border border-[#E0DED6] bg-white px-3.5 py-2 text-xs font-bold hover:border-[#111111]">{s}</button>)}
                  </div>
                </div>
              )}
              {(favTools.length > 0 || recentTools.length > 0) && (
                <div>
                  <div className="mb-2 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#707070]">Quick access</div>
                  <div className="space-y-2">
                    {[...recentTools, ...favTools].filter((v, i, a) => a.findIndex((x) => x.key === v.key) === i).slice(0, 5).map((t) => (
                      <button key={t.key} onClick={() => go(t.key)} className="pressable flex w-full items-center gap-3 rounded-2xl bg-white p-3 text-left hover:border-[#111111] border border-transparent">
                        <span className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon, "h-4 w-4")}</span>
                        <span className="text-sm font-extrabold">{t.name}</span>
                        <ChevronRight className="ml-auto h-4 w-4 text-[#B9B6AC]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div>
                <div className="mb-2 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#707070]">Browse categories</div>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.filter((c) => c.key !== "all").map((c) => (
                    <button key={c.key} onClick={() => setQ(c.label)} className="pressable rounded-full px-3.5 py-2 text-xs font-extrabold" style={{ background: c.tint === "#111111" ? "#111111" : c.tint, color: c.tint === "#111111" ? "#fff" : "#111" }}>{c.label}</button>
                  ))}
                </div>
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="py-10 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white"><Search className="h-5 w-5 text-[#B9B6AC]" /></div>
              <p className="mt-3 font-display font-extrabold">No tools for “{q}”</p>
              <p className="text-xs font-medium text-[#707070]">Try “pdf”, “qr”, “password” or “resize”</p>
            </div>
          ) : (
            <div className="space-y-2">
              {results.map((t) => (
                <button key={t.key} onClick={() => go(t.key)} className="pressable flex w-full items-center gap-3 rounded-2xl bg-white p-3 text-left border border-transparent hover:border-[#111111]">
                  <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon)}</span>
                  <span>
                    <span className="block text-sm font-extrabold">{t.name}</span>
                    <span className="block text-xs font-medium text-[#707070]">{t.tagline}</span>
                  </span>
                  <ArrowUpRight className="ml-auto h-4 w-4 text-[#B9B6AC]" />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="flex items-center justify-center gap-1.5 border-t border-[#E8E6E0] bg-white px-4 py-2.5 text-[11px] font-bold text-[#707070]">
          <ShieldCheck className="h-3.5 w-3.5" /> Search runs on-device · nothing is sent anywhere
        </div>
      </div>
    </div>
  );
}

// ─── Bottom nav (mobile) ───
export function BottomNav({ view, onNav, onSearch }: { view: string; onNav: (v: ViewKey) => void; onSearch: () => void }) {
  const item = (key: ViewKey, label: string, icon: React.ReactNode, active: boolean) => (
    <button key={key} onClick={() => onNav(key)} className="pressable flex flex-1 flex-col items-center gap-1 py-1">
      <span className={`grid h-9 w-12 place-items-center rounded-full transition ${active ? "bg-[#111111] text-white" : "text-[#8A877D]"}`}>{icon}</span>
      <span className={`text-[10px] font-extrabold ${active ? "text-[#111111]" : "text-[#8A877D]"}`}>{label}</span>
    </button>
  );
  return (
    <nav className="fixed inset-x-0 bottom-0 z-[60] lg:hidden">
      <div className="mx-3 mb-3 rounded-[26px] border border-[#111111]/10 bg-white/95 px-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] pt-2 shadow-[0_18px_50px_-18px_rgba(17,17,17,0.45)] backdrop-blur-xl">
        <div className="flex items-center">
          {item("home", "Home", <House className="h-5 w-5" />, view === "home")}
          {item("tools", "Tools", <LayoutGrid className="h-5 w-5" />, view === "tools" || view.startsWith("cat-") || TOOLS.some((t) => t.key === view))}
          <button onClick={onSearch} className="pressable mx-1 grid h-14 w-14 -translate-y-3 place-items-center rounded-full bg-[#111111] text-white shadow-[0_14px_28px_-10px_rgba(17,17,17,0.7)] ring-4 ring-[#F7F7F4]">
            <Search className="h-6 w-6" />
          </button>
          {item("history", "History", <History className="h-5 w-5" />, view === "history")}
          {item("pro", "Pro", <Crown className="h-5 w-5" />, view === "pro")}
        </div>
      </div>
    </nav>
  );
}

// ─── Sidebar (desktop) ───
export function Sidebar({ view, onNav, onSearch, histCount, pro }: { view: string; onNav: (v: ViewKey) => void; onSearch: () => void; histCount: number; pro: boolean }) {
  const link = (key: ViewKey, label: string, icon: React.ReactNode, badge?: string | number) => {
    const active = view === key || (key === "tools" && (view.startsWith("cat-") || TOOLS.some((t) => t.key === view)));
    return (
      <button onClick={() => onNav(key)} className={`pressable flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold transition ${active ? "bg-[#111111] text-white shadow-lg" : "text-[#5b594f] hover:bg-white"}`}>
        {icon}
        {label}
        {badge !== undefined && <span className={`ml-auto rounded-full px-2 py-0.5 text-[11px] font-extrabold tabular-nums ${active ? "bg-white/15 text-white" : "bg-[#111111] text-white"}`}>{badge}</span>}
      </button>
    );
  };
  return (
    <aside className="sticky top-0 hidden h-screen w-[272px] shrink-0 flex-col gap-2 overflow-y-auto p-5 lg:flex">
      <div className="rounded-[26px] bg-white p-4 shadow-[0_10px_40px_-20px_rgba(17,17,17,0.25)]">
        <Logo />
        <button onClick={onSearch} className="pressable mt-4 flex w-full items-center gap-2 rounded-2xl bg-[#F4F3EE] px-4 py-3 text-[13px] font-bold text-[#8A877D] hover:bg-[#ECEAE3]">
          <Search className="h-4 w-4" /> Search tools…
          <kbd className="ml-auto rounded-md bg-white px-1.5 py-0.5 text-[10px] font-extrabold text-[#8A877D] shadow-sm">⌘K</kbd>
        </button>
      </div>
      <div className="rounded-[26px] bg-white p-3 shadow-[0_10px_40px_-20px_rgba(17,17,17,0.25)]">
        {link("home", "Home", <House className="h-[18px] w-[18px]" />)}
        {link("tools", "All Tools", <LayoutGrid className="h-[18px] w-[18px]" />, 12)}
        {link("history", "History", <History className="h-[18px] w-[18px]" />, histCount)}
        {link("settings", "Settings", <Settings className="h-[18px] w-[18px]" />)}
      </div>
      <button onClick={() => onNav("pro")} className="pressable relative overflow-hidden rounded-[26px] bg-[#111111] p-5 text-left text-white">
        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-[#CDEFE6]/20" />
        <div className="absolute -bottom-10 -left-6 h-28 w-28 rounded-full bg-[#E8D8F6]/20" />
        <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-[#F4D9C6]"><Crown className="h-4 w-4" /> {pro ? "QwikTools Pro active" : "QwikTools Pro"}</div>
        <div className="mt-1.5 font-display text-[19px] font-extrabold leading-tight tracking-tight">{pro ? "Thanks for going Pro." : "Bigger batches. No ads."}</div>
        <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-2 text-xs font-extrabold text-[#111111]">{pro ? "Manage" : "Get Pro"} <ChevronRight className="h-3.5 w-3.5" /></div>
      </button>
      <div className="rounded-[26px] border border-dashed border-[#CFCCC0] p-4">
        <div className="flex items-center gap-2 text-xs font-extrabold"><span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" /> 100% offline</div>
        <p className="mt-1 text-[11px] font-medium leading-relaxed text-[#707070]">Every tool runs on this device. Files are never uploaded to a QwikTools server.</p>
      </div>
    </aside>
  );
}

// ─── Onboarding ───
export function Onboarding({ onDone }: { onDone: () => void }) {
  const [page, setPage] = useState(0);
  const slides = [
    { tint: "#CDEFE6", icon: <Zap className="h-8 w-8" />, title: "12 useful tools.\nOne app.", body: "QR, images, PDFs, calculators and text tools — one consistent workflow, zero clutter.", chip: "01 · Everything in one place" },
    { tint: "#E8D8F6", icon: <ShieldCheck className="h-8 w-8" />, title: "Your files stay\non your phone.", body: "Local-first processing. No account, no uploads, no conversion server watching your files.", chip: "02 · Private by architecture" },
    { tint: "#F4D9C6", icon: <Flame className="h-8 w-8" />, title: "Fast even\nwhen offline.", body: "Airplane mode? Basement studio? QwikTools keeps working at full speed.", chip: "03 · Offline-first" },
  ];
  const s = slides[page];
  return (
    <div className="fixed inset-0 z-[100] overflow-y-auto bg-[#F7F7F4]">
      <div className="mx-auto flex min-h-full w-full max-w-md flex-col p-5">
        <div className="flex items-center justify-between">
          <Logo />
          <button onClick={onDone} className="pressable rounded-full bg-white px-4 py-2 text-xs font-extrabold shadow-sm">Skip</button>
        </div>
        <div key={page} className="pop-in mt-6 flex-1 rounded-[30px] p-7 transition-colors duration-300" style={{ background: s.tint }}>
          <span className="inline-block rounded-full bg-[#111111] px-3 py-1.5 text-[11px] font-extrabold text-white">{s.chip}</span>
          <div className="mt-8 grid h-20 w-20 place-items-center rounded-[26px] bg-white shadow-sm float-slow">{s.icon}</div>
          <h1 className="mt-6 whitespace-pre-line font-display text-[38px] font-extrabold leading-[1.02] tracking-tight">{s.title}</h1>
          <p className="mt-3 max-w-[30ch] text-[15px] font-medium leading-relaxed text-[#111111]/70">{s.body}</p>
          <div className="mt-8 flex gap-1.5">
            {slides.map((_, i) => <span key={i} className={`h-2 rounded-full transition-all ${i === page ? "w-8 bg-[#111111]" : "w-2 bg-[#111111]/20"}`} />)}
          </div>
        </div>
        <div className="mt-4 flex gap-2 pb-4">
          {page > 0 && <button onClick={() => setPage(page - 1)} className="pressable rounded-2xl border-2 border-[#111111] px-6 py-4 text-sm font-extrabold">Back</button>}
          <button onClick={() => (page === slides.length - 1 ? onDone() : setPage(page + 1))} className="pressable flex-1 rounded-2xl bg-[#111111] py-4 font-display text-[15px] font-extrabold text-white">
            {page === slides.length - 1 ? "Get Started" : "Next"}
          </button>
        </div>
        <p className="pb-2 text-center text-[11px] font-semibold text-[#8A877D]">No permissions asked upfront · camera & files only when a tool needs them</p>
      </div>
    </div>
  );
}

// ─── Splash ───
export function Splash() {
  return (
    <div className="fixed inset-0 z-[110] grid place-items-center bg-[#F7F7F4]">
      <div className="text-center">
        <div className="mx-auto grid h-[76px] w-[76px] place-items-center rounded-[24px] bg-[#111111] shadow-2xl">
          <svg viewBox="0 0 32 32" className="h-11 w-11">
            <path d="M7 7h7v7H7zM18 7h7v7h-7zM7 18h7v7H7z" fill="none" stroke="#CDEFE6" strokeWidth="2.6" strokeLinejoin="round" />
            <path d="M18 18h4v4h-4z" fill="#F4D9C6" />
            <path d="M23 23h2v2h-2z" fill="#E8D8F6" />
          </svg>
        </div>
        <div className="mt-4 font-display text-2xl font-extrabold tracking-tight">QwikTools</div>
        <div className="mt-1 text-xs font-bold uppercase tracking-[0.2em] text-[#707070]">Local utility engine</div>
        <div className="mx-auto mt-5 h-1.5 w-36 overflow-hidden rounded-full bg-[#E8E6E0]">
          <div className="h-full w-1/3 rounded-full bg-[#111111]" style={{ animation: "progress-shimmer 1.1s linear infinite" }} />
        </div>
      </div>
    </div>
  );
}

export function EmptyHistory({ onBrowse }: { onBrowse: () => void }) {
  return (
    <div className="rounded-[26px] border border-dashed border-[#CFCCC0] bg-white/60 p-10 text-center">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#111111] text-white"><History className="h-6 w-6" /></div>
      <p className="mt-4 font-display text-lg font-extrabold">No history yet</p>
      <p className="mx-auto mt-1 max-w-[32ch] text-sm font-medium text-[#707070]">Run any tool and a lightweight record (name, time, sizes) is kept here — on this device only.</p>
      <button onClick={onBrowse} className="pressable mt-4 rounded-2xl bg-[#111111] px-5 py-3 text-sm font-extrabold text-white">Browse tools</button>
    </div>
  );
}

export function ClearButton({ onClear }: { onClear: () => void }) {
  const [arm, setArm] = useState(false);
  useEffect(() => { if (!arm) return; const t = setTimeout(() => setArm(false), 3200); return () => clearTimeout(t); }, [arm]);
  return (
    <button onClick={() => (arm ? (onClear(), setArm(false)) : setArm(true))} className={`pressable flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-extrabold transition ${arm ? "bg-red-600 text-white" : "bg-white text-[#707070] hover:text-red-600"}`}>
      <Trash2 className="h-3.5 w-3.5" /> {arm ? "Tap again to confirm" : "Clear"}
    </button>
  );
}

export function TopBarMobile({ onSearch, onSettings }: { onSearch: () => void; onSettings: () => void }) {
  return (
    <div className="flex items-center justify-between lg:hidden">
      <Logo />
      <div className="flex items-center gap-2">
        <button onClick={onSearch} className="pressable relative grid h-10 w-10 place-items-center rounded-full bg-white shadow-sm"><Bell className="h-[18px] w-[18px]" /><span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-[#F4D9C6] ring-2 ring-white" /></button>
        <button onClick={onSettings} className="pressable grid h-10 w-10 place-items-center rounded-full bg-[#111111] text-white"><Settings className="h-[18px] w-[18px]" /></button>
      </div>
    </div>
  );
}

export function CategoryPills({ active, onPick }: { active: string; onPick: (k: string) => void }) {
  return (
    <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 py-1">
      {CATEGORIES.map((c) => {
        const on = active === c.key;
        return (
          <button key={c.key} onClick={() => onPick(c.key)} className={`pressable shrink-0 rounded-full px-4 py-2.5 text-[13px] font-extrabold transition ${on ? "bg-[#111111] text-white shadow-lg" : "bg-white text-[#5b594f] hover:bg-[#ECEAE3]"}`}>
            {c.label}
          </button>
        );
      })}
    </div>
  );
}
