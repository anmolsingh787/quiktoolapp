import { useMemo, useState } from "react";
import { Search, Star, ChevronRight, History as HistoryIcon, Crown, ShieldCheck, Trash2, Zap, Sparkles, ArrowUpRight, Check, Settings as SettingsIcon, FolderOpen, Image as ImageIcon, FileText, HardDrive, RotateCcw, Share2, Star as StarIcon, QrCode, Calculator, Type, Layers, WifiOff, ChevronLeft, SlidersHorizontal } from "lucide-react";
import { CATEGORIES, TOOLS, fmtBytes, fullDate, isPro, loadFavs, loadHistory, loadRecent, loadSettings, saveHistory, saveSettings, setPro, timeAgo, tintBg, tintFg, toggleFav, type AppSettings, type HistoryItem, type ViewKey } from "../lib/core";
import { CategoryPills, ClearButton, EmptyHistory, OfflineBadge, iconFor } from "../components/chrome";

// ─── HOME ───
export function HomeScreen({ onOpen, onNav, onSearch }: { onOpen: (k: string) => void; onNav: (v: ViewKey) => void; onSearch: () => void }) {
  const [favs] = useState(loadFavs());
  const [recent] = useState(loadRecent());
  const [hist] = useState(loadHistory());
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  void favs;
  const recentTools = recent.map((k) => TOOLS.find((t) => t.key === k)).filter(Boolean).slice(0, 3) as typeof TOOLS;
  const actionsWeek = hist.filter((h) => Date.now() - h.timestamp < 7 * 86400000).length;

  return (
    <div className="space-y-5">
      {/* greeting */}
      <div>
        <p className="text-[13px] font-bold text-[#707070]">{greet} 👋</p>
        <h1 className="font-display text-[30px] font-extrabold leading-[1.05] tracking-tight">What are we<br />fixing today?</h1>
      </div>

      {/* stats */}
      <div className="grid grid-cols-2 gap-2.5">
        <button onClick={() => onNav("tools")} className="pressable relative overflow-hidden rounded-[24px] bg-[#111111] p-5 text-left text-white">
          <Zap className="absolute -bottom-3 -right-3 h-20 w-20 text-white/10" />
          <div className="font-display text-[34px] font-extrabold leading-none">12</div>
          <div className="mt-1 text-[13px] font-extrabold">Tools ready</div>
          <div className="text-[11px] font-medium text-white/50">All offline · tap to browse</div>
        </button>
        <button onClick={() => onNav("history")} className="pressable relative overflow-hidden rounded-[24px] bg-[#CDEFE6] p-5 text-left">
          <HistoryIcon className="absolute -bottom-3 -right-3 h-20 w-20 text-[#111111]/10" />
          <div className="font-display text-[34px] font-extrabold leading-none tabular-nums">{actionsWeek}</div>
          <div className="mt-1 text-[13px] font-extrabold">Actions this week</div>
          <div className="text-[11px] font-semibold text-[#111111]/50">Counted on-device</div>
        </button>
      </div>

      {/* search shortcut */}
      <button onClick={onSearch} className="pressable flex w-full items-center gap-3 rounded-[22px] border border-[#E8E6E0] bg-white px-5 py-4 text-left shadow-sm">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-[#F4F3EE]"><Search className="h-4 w-4" /></span>
        <span className="text-sm font-bold text-[#8A877D]">Search “compress”, “qr”, “merge”…</span>
        <span className="ml-auto rounded-full bg-[#111111] px-3 py-1.5 text-[11px] font-extrabold text-white">⌘K</span>
      </button>

      {/* categories */}
      <div>
        <div className="mb-2.5 flex items-center justify-between">
          <h2 className="font-display text-[17px] font-extrabold tracking-tight">Categories</h2>
          <button onClick={() => onNav("tools")} className="flex items-center gap-0.5 text-xs font-extrabold text-[#707070]">View all <ChevronRight className="h-3.5 w-3.5" /></button>
        </div>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
          {[
            { k: "cat-qr", label: "QR Tools", sub: "Scan · Create", tint: "#CDEFE6", icon: <QrCode className="h-5 w-5" />, count: 2 },
            { k: "cat-image", label: "Image Tools", sub: "Shrink · Resize", tint: "#E8D8F6", icon: <ImageIcon className="h-5 w-5" />, count: 3 },
            { k: "cat-pdf", label: "PDF Tools", sub: "Build · Merge", tint: "#F4D9C6", icon: <FileText className="h-5 w-5" />, count: 3 },
            { k: "cat-calc", label: "Calculators", sub: "% · Units", tint: "#FDF6E9", icon: <Calculator className="h-5 w-5" />, count: 2 },
            { k: "cat-text", label: "Text & Security", sub: "Words · Secrets", tint: "#111111", icon: <Type className="h-5 w-5" />, count: 2, light: true },
            { k: "pro", label: "Go Pro", sub: "Bigger · Faster", tint: "#111111", icon: <Crown className="h-5 w-5 text-[#F4D9C6]" />, count: 0, light: true },
          ].map((c) => (
            <button key={c.k} onClick={() => onNav(c.k as ViewKey)} className="pressable rounded-[22px] p-4 text-left transition hover:-translate-y-0.5" style={{ background: c.tint, color: c.light ? "#fff" : "#111" }}>
              <div className="flex items-start justify-between">
                {c.icon}
                {c.count > 0 && <span className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${c.light ? "bg-white/15" : "bg-[#111111]/10"}`}>{c.count}</span>}
              </div>
              <div className="mt-6 font-display text-[15px] font-extrabold leading-tight">{c.label}</div>
              <div className={`text-[11px] font-semibold ${c.light ? "text-white/55" : "text-[#111111]/55"}`}>{c.sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* recent */}
      {recentTools.length > 0 && (
        <div>
          <h2 className="mb-2.5 font-display text-[17px] font-extrabold tracking-tight">Jump back in</h2>
          <div className="space-y-2">
            {recentTools.map((t) => (
              <button key={t.key} onClick={() => onOpen(t.key)} className="pressable flex w-full items-center gap-3 rounded-[22px] border border-[#E8E6E0] bg-white p-3 text-left">
                <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon)}</span>
                <span className="min-w-0"><span className="block truncate text-sm font-extrabold">{t.name}</span><span className="block truncate text-xs font-medium text-[#707070]">{t.tagline}</span></span>
                <span className="ml-auto grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#111111] text-white"><ArrowUpRight className="h-4 w-4" /></span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* favorites */}
      <div>
        <h2 className="mb-2.5 font-display text-[17px] font-extrabold tracking-tight">Favorites {favs.length > 0 && <span className="ml-1 rounded-full bg-[#F4D9C6] px-2 py-0.5 align-middle text-[11px]">{favs.length}</span>}</h2>
        {favs.length === 0 ? (
          <div className="rounded-[22px] border border-dashed border-[#CFCCC0] bg-white/60 p-5 text-center text-[13px] font-semibold text-[#707070]">Tap the <Star className="inline h-3.5 w-3.5" /> on any tool to pin it here.</div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {TOOLS.filter((t) => favs.includes(t.key)).map((t) => (
              <button key={t.key} onClick={() => onOpen(t.key)} className="pressable flex items-center gap-2.5 rounded-2xl bg-white p-3 text-left border border-[#E8E6E0]">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon, "h-4 w-4")}</span>
                <span className="truncate text-[13px] font-extrabold">{t.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* privacy strip */}
      <div className="flex items-start gap-3 rounded-[22px] bg-[#E8D8F6]/60 p-4">
        <ShieldCheck className="h-5 w-5 shrink-0" />
        <p className="text-[12.5px] font-semibold leading-relaxed text-[#111111]/75"><b>Private by architecture.</b> QwikTools core processing happens locally on your device — no file-processing server, no account, works in airplane mode.</p>
      </div>
    </div>
  );
}

// ─── ALL TOOLS ───
export function AllTools({ onOpen }: { onOpen: (k: string) => void }) {
  const [cat, setCat] = useState("all");
  const [favs, setFavs] = useState(loadFavs());
  const list = useMemo(() => (cat === "all" ? TOOLS : TOOLS.filter((t) => t.category === cat)), [cat]);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-[28px] font-extrabold tracking-tight">All tools</h1>
        <p className="text-[13px] font-medium text-[#707070]">12 reliable tools · every one works offline</p>
      </div>
      <CategoryPills active={cat} onPick={setCat} />
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        {list.map((t) => (
          <div key={t.key} className="pop-in">
            <ToolCardInline toolKey={t.key} fav={favs.includes(t.key)} onOpen={() => onOpen(t.key)} onFav={() => setFavs(toggleFav(t.key))} />
          </div>
        ))}
      </div>
    </div>
  );
}

function ToolCardInline({ toolKey, fav, onOpen, onFav }: { toolKey: string; fav: boolean; onOpen: () => void; onFav: () => void }) {
  const t = TOOLS.find((x) => x.key === toolKey)!;
  return (
    <button onClick={onOpen} className="pressable group w-full overflow-hidden rounded-[22px] border border-[#E8E6E0] bg-white p-4 text-left hover:border-[#111111]">
      <div className="flex items-start justify-between">
        <span className="grid h-11 w-11 place-items-center rounded-2xl transition-transform group-hover:scale-105" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon)}</span>
        <span onClick={(e) => { e.stopPropagation(); onFav(); }} className={`grid h-8 w-8 cursor-pointer place-items-center rounded-full ${fav ? "bg-[#111111] text-[#F4D9C6]" : "bg-[#F4F3EE] text-[#B9B6AC]"}`}><StarIcon className={`h-4 w-4 ${fav ? "fill-current" : ""}`} /></span>
      </div>
      <div className="mt-3 font-display text-[15px] font-extrabold leading-tight">{t.name}</div>
      <div className="mt-0.5 line-clamp-1 text-xs font-medium text-[#707070]">{t.tagline}</div>
    </button>
  );
}

// ─── CATEGORY ───
const CATMETA: Record<string, { title: string; blurb: string; tint: string; icon: React.ReactNode }> = {
  qr: { title: "QR Tools", blurb: "Scan with camera or image · create styled codes", tint: "#CDEFE6", icon: <QrCode className="h-6 w-6" /> },
  image: { title: "Image Tools", blurb: "Compress, resize and convert — right on device", tint: "#E8D8F6", icon: <ImageIcon className="h-6 w-6" /> },
  pdf: { title: "PDF Tools", blurb: "Build from photos · render pages · merge files", tint: "#F4D9C6", icon: <FileText className="h-6 w-6" /> },
  calc: { title: "Calculators", blurb: "Percentages and 30+ unit conversions", tint: "#FDF6E9", icon: <Calculator className="h-6 w-6" /> },
  text: { title: "Text & Security", blurb: "Count words live · forge strong passwords", tint: "#111111", icon: <Type className="h-6 w-6 text-white" /> },
};
export function CategoryScreen({ cat, onOpen, onBack }: { cat: string; onOpen: (k: string) => void; onBack: () => void }) {
  const [favs, setFavs] = useState(loadFavs());
  const meta = CATMETA[cat];
  const tools = TOOLS.filter((t) => t.category === cat);
  return (
    <div className="space-y-4">
      <button onClick={onBack} className="pressable flex items-center gap-1.5 text-xs font-extrabold text-[#707070]"><ChevronLeft className="h-4 w-4" /> All tools</button>
      <div className="rounded-[28px] p-6" style={{ background: meta.tint, color: meta.tint === "#111111" ? "#fff" : "#111" }}>
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/70 text-[#111]">{meta.icon}</div>
        <h1 className="mt-3 font-display text-[26px] font-extrabold tracking-tight">{meta.title}</h1>
        <p className={`text-[13px] font-semibold ${meta.tint === "#111111" ? "text-white/60" : "text-[#111111]/60"}`}>{meta.blurb}</p>
        <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[#111111] px-3 py-1.5 text-[11px] font-extrabold text-white"><WifiOff className="h-3 w-3" /> Works offline</div>
      </div>
      <div className="grid gap-2.5 sm:grid-cols-2">
        {tools.map((t, i) => (
          <button key={t.key} onClick={() => onOpen(t.key)} className="pressable flex items-center gap-4 rounded-[24px] border border-[#E8E6E0] bg-white p-4 text-left hover:border-[#111111]">
            <span className="font-display text-[13px] font-extrabold text-[#B9B6AC]">0{i + 1}</span>
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl" style={{ background: tintBg(t.tint), color: tintFg(t.tint) }}>{iconFor(t.icon)}</span>
            <span className="min-w-0"><span className="block font-display text-[15px] font-extrabold">{t.name}</span><span className="block truncate text-xs font-medium text-[#707070]">{t.tagline}</span></span>
            <span className="ml-auto flex shrink-0 items-center gap-1.5">
              <span onClick={(e) => { e.stopPropagation(); setFavs(toggleFav(t.key)); }} className={`grid h-8 w-8 cursor-pointer place-items-center rounded-full ${favs.includes(t.key) ? "bg-[#111111] text-[#F4D9C6]" : "bg-[#F4F3EE] text-[#B9B6AC]"}`}><StarIcon className={`h-3.5 w-3.5 ${favs.includes(t.key) ? "fill-current" : ""}`} /></span>
              <ChevronRight className="h-4 w-4 text-[#B9B6AC]" />
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── HISTORY ───
export function HistoryScreen({ onOpen }: { onOpen: (k: string) => void }) {
  const [items, setItems] = useState<HistoryItem[]>(loadHistory());
  const [tab, setTab] = useState<"all" | "qr" | "image" | "pdf">("all");
  const refresh = () => setItems(loadHistory());
  useMemo(() => {
    const fn = () => refresh();
    window.addEventListener("qwik-history", fn);
    return () => window.removeEventListener("qwik-history", fn);
  }, []);

  const filtered = items.filter((h) => {
    if (tab === "all") return true;
    if (tab === "qr") return h.featureKey.startsWith("qr");
    if (tab === "image") return h.featureKey.startsWith("image");
    return h.featureKey.includes("pdf") || h.featureKey === "pdf-merge";
  });

  const toggleStar = (id: string) => {
    const next = items.map((h) => (h.id === id ? { ...h, favorite: !h.favorite } : h));
    setItems(next); saveHistory(next);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-[28px] font-extrabold tracking-tight">History</h1>
          <p className="text-[13px] font-medium text-[#707070]">Metadata only — never file contents · stored on-device</p>
        </div>
        {items.length > 0 && <ClearButton onClear={() => { saveHistory([]); setItems([]); }} />}
      </div>
      <div className="flex gap-2">
        {(["all", "qr", "image", "pdf"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`pressable rounded-full px-4 py-2 text-[13px] font-extrabold capitalize ${tab === t ? "bg-[#111111] text-white" : "bg-white"}`}>{t === "all" ? "All" : t === "qr" ? "QR" : t === "image" ? "Image" : "PDF"}</button>
        ))}
      </div>
      {filtered.length === 0 ? <EmptyHistory onBrowse={() => onOpen("tools")} /> : (
        <div className="space-y-2">
          {filtered.map((h) => {
            const t = TOOLS.find((x) => x.key === h.featureKey);
            return (
              <div key={h.id} className="flex items-center gap-3 rounded-[20px] border border-[#E8E6E0] bg-white p-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ background: t ? tintBg(t.tint) : "#F4F3EE", color: t ? tintFg(t.tint) : "#111" }}>{t ? iconFor(t.icon, "h-4 w-4") : <HistoryIcon className="h-4 w-4" />}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13.5px] font-extrabold">{h.toolName} <span className={`ml-1 rounded-full px-1.5 py-0.5 text-[10px] ${h.status === "success" ? "bg-[#CDEFE6]" : "bg-red-100 text-red-700"}`}>{h.status}</span></div>
                  <div className="truncate text-xs font-medium text-[#707070]">{h.detail}</div>
                  <div className="text-[11px] font-bold text-[#A9A69B]">{timeAgo(h.timestamp)} · {fullDate(h.timestamp)}{h.meta ? ` · ${h.meta}` : ""}</div>
                </div>
                <div className="flex shrink-0 flex-col gap-1">
                  <button onClick={() => toggleStar(h.id)} className={`grid h-8 w-8 place-items-center rounded-full pressable ${h.favorite ? "bg-[#111111] text-[#F4D9C6]" : "bg-[#F4F3EE] text-[#B9B6AC]"}`}><StarIcon className={`h-3.5 w-3.5 ${h.favorite ? "fill-current" : ""}`} /></button>
                  {t && <button onClick={() => onOpen(t.key)} className="pressable rounded-full bg-[#F4F3EE] px-2.5 py-1.5 text-[10px] font-extrabold hover:bg-[#111111] hover:text-white">Use again</button>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── PRO ───
export function ProScreen() {
  const [pro, setProState] = useState(isPro());
  const [plan, setPlan] = useState<"lifetime" | "monthly">("lifetime");
  const buy = () => {
    // Simulated Play Billing sheet (client-only v1, no backend)
    setPro(true); setProState(true);
  };
  return (
    <div className="space-y-4">
      <div className="relative overflow-hidden rounded-[30px] bg-[#111111] p-7 text-white">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-[#CDEFE6]/15" />
        <div className="absolute -bottom-20 -left-10 h-48 w-48 rounded-full bg-[#E8D8F6]/15" />
        <div className="absolute right-8 top-20 h-16 w-16 rounded-full bg-[#F4D9C6]/25" />
        <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#F4D9C6]"><Crown className="h-4 w-4" /> QwikTools Pro</div>
        <h1 className="mt-2 max-w-[16ch] font-display text-[32px] font-extrabold leading-[1.02] tracking-tight">{pro ? "You're Pro. Everything's unlocked." : "Do more, faster. Still offline."}</h1>
        <p className="mt-2 max-w-[38ch] text-[13.5px] font-medium text-white/60">Bigger batches, premium presets, exclusive QR styles — and zero ads. One purchase, yours on this device.</p>
        {!pro && (
          <div className="mt-5 grid grid-cols-2 gap-2">
            <button onClick={() => setPlan("monthly")} className={`pressable rounded-2xl p-4 text-left ring-2 transition ${plan === "monthly" ? "bg-white text-[#111111] ring-[#CDEFE6]" : "bg-white/10 ring-transparent"}`}>
              <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-60">Monthly</div>
              <div className="font-display text-xl font-extrabold">$1.99<span className="text-xs font-bold opacity-60">/mo</span></div>
            </button>
            <button onClick={() => setPlan("lifetime")} className={`pressable relative rounded-2xl p-4 text-left ring-2 transition ${plan === "lifetime" ? "bg-white text-[#111111] ring-[#F4D9C6]" : "bg-white/10 ring-transparent"}`}>
              <span className="absolute -top-2.5 right-3 rounded-full bg-[#F4D9C6] px-2 py-0.5 text-[10px] font-extrabold text-[#111111]">BEST VALUE</span>
              <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-60">Lifetime</div>
              <div className="font-display text-xl font-extrabold">$14.99<span className="text-xs font-bold opacity-60"> once</span></div>
            </button>
          </div>
        )}
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        {[
          ["#CDEFE6", "No ads", "Clean, quiet tools"],
          ["#E8D8F6", "50-file batches", "Free is 20 — 2.5× more"],
          ["#F4D9C6", "Premium presets", "Pro compression & QR styles"],
          ["#FDF6E9", "Priority engine", "Fastest local pipeline"],
        ].map(([tint, a, b]) => (
          <div key={a} className="flex items-center gap-3 rounded-[20px] border border-[#E8E6E0] bg-white p-4">
            <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: tint }}><Check className="h-4 w-4" /></span>
            <span><span className="block text-sm font-extrabold">{a}</span><span className="block text-xs font-medium text-[#707070]">{b}</span></span>
          </div>
        ))}
      </div>

      {pro ? (
        <div className="rounded-[24px] bg-[#CDEFE6] p-5 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#111111] text-[#CDEFE6]"><Check className="h-6 w-6" /></div>
          <p className="mt-2 font-display text-lg font-extrabold">Pro is active on this device</p>
          <p className="text-xs font-semibold text-[#111111]/60">Cached entitlement · works fully offline</p>
          <button onClick={() => { setPro(false); setProState(false); }} className="pressable mt-3 rounded-full bg-[#111111] px-5 py-2.5 text-xs font-extrabold text-white">Restore / manage (demo: deactivate)</button>
        </div>
      ) : (
        <>
          <button onClick={buy} className="pressable w-full rounded-[22px] bg-[#111111] py-4.5 font-display text-[16px] font-extrabold text-white py-4 shadow-xl">Get Pro {plan === "monthly" ? "· $1.99/mo" : "· $14.99 once"}</button>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={buy} className="pressable rounded-2xl border-[1.5px] border-[#E0DED6] bg-white py-3 text-[13px] font-extrabold"><RotateCcw className="mr-1 inline h-3.5 w-3.5" />Restore purchase</button>
            <button className="pressable rounded-2xl border-[1.5px] border-[#E0DED6] bg-white py-3 text-[13px] font-extrabold"><Share2 className="mr-1 inline h-3.5 w-3.5" />Gift Pro</button>
          </div>
          <p className="text-center text-[11px] font-medium leading-relaxed text-[#8A877D]">Demo billing — no charge, no backend. Production uses Google Play Billing with locally cached entitlement.<br />Free forever: all 12 core tools · reasonable batch limits.</p>
        </>
      )}

      <div className="rounded-[22px] border border-[#E8E6E0] bg-white p-4">
        <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Free vs Pro</div>
        <div className="mt-2 space-y-1.5 text-[13px] font-semibold">
          {[["Batch images", "20 files", "50 files"], ["PDF pages / render", "20 pages", "100 pages"], ["Ads", "Optional, subtle", "None"], ["QR styles", "4 themes", "12 + logo"], ["Export formats", "Core", "Core + TIFF/BMP"]].map(([a, f, p]) => (
            <div key={a} className="grid grid-cols-[1fr_auto_auto] items-center gap-2 rounded-xl bg-[#F7F7F4] px-3 py-2">
              <span className="font-extrabold">{a}</span><span className="text-[#707070]">{f}</span><span className="rounded-full bg-[#111111] px-2 py-0.5 text-[11px] font-extrabold text-white">{p}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── SETTINGS ───
export function SettingsScreen({ onNav }: { onNav: (v: ViewKey) => void }) {
  const [s, setS] = useState<AppSettings>(loadSettings());
  const [pro, setProState] = useState(isPro());
  const [freed, setFreed] = useState(false);
  const upd = (patch: Partial<AppSettings>) => { const n = { ...s, ...patch }; setS(n); saveSettings(n); };

  const row = (icon: React.ReactNode, tint: string, title: string, sub: string, control?: React.ReactNode, action?: () => void) => (
    <div onClick={action} className={`flex items-center gap-3 rounded-[20px] border border-[#E8E6E0] bg-white p-3.5 ${action ? "cursor-pointer pressable hover:border-[#111111]" : ""}`}>
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ background: tint }}>{icon}</span>
      <span className="min-w-0 flex-1"><span className="block truncate text-[13.5px] font-extrabold">{title}</span><span className="block truncate text-xs font-medium text-[#707070]">{sub}</span></span>
      {control || (action && <ChevronRight className="h-4 w-4 shrink-0 text-[#B9B6AC]" />)}
    </div>
  );
  const toggle = (on: boolean, fn: () => void) => (
    <button onClick={(e) => { e.stopPropagation(); fn(); }} className={`grid h-7 w-12 shrink-0 place-items-center rounded-full transition ${on ? "bg-[#111111]" : "bg-[#D8D5CC]"}`}><span className={`h-5 w-5 rounded-full bg-white transition-all ${on ? "translate-x-2.5" : "-translate-x-2.5"}`} /></button>
  );

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-[28px] font-extrabold tracking-tight">Settings</h1>
        <p className="text-[13px] font-medium text-[#707070]">Everything stored locally · no account</p>
      </div>

      <div className="flex items-center gap-3 rounded-[24px] bg-[#111111] p-4 text-white">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#CDEFE6] text-[#111111]"><SettingsIcon className="h-5 w-5" /></span>
        <div><div className="text-sm font-extrabold">{pro ? "QwikTools Pro" : "QwikTools Free"}</div><div className="text-xs font-medium text-white/50">{pro ? "All limits lifted" : "12 tools · 20-file batches"}</div></div>
        <button onClick={() => onNav("pro")} className="pressable ml-auto rounded-full bg-white px-4 py-2 text-xs font-extrabold text-[#111111]">{pro ? "Manage" : "Get Pro"}</button>
      </div>

      <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Defaults</div>
      <div className="space-y-2">
        <div className="rounded-[20px] border border-[#E8E6E0] bg-white p-3.5">
          <div className="flex justify-between text-[13px] font-extrabold"><span>Default image quality</span><span className="tabular-nums">{s.quality}%</span></div>
          <input type="range" min={10} max={100} value={s.quality} onChange={(e) => upd({ quality: +e.target.value })} className="qwik-range mt-2 w-full" style={{ ["--fill" as any]: `${s.quality}%` }} />
        </div>
        {row(<ImageIcon className="h-4 w-4" />, "#E8D8F6", "Default export format", "Used by compressor & converter",
          <div className="flex gap-1">{["webp", "jpg", "png"].map((f) => <button key={f} onClick={(e) => { e.stopPropagation(); upd({ format: f }); }} className={`rounded-full px-2.5 py-1.5 text-[11px] font-extrabold uppercase pressable ${s.format === f ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{f}</button>)}</div>)}
        {row(<FileText className="h-4 w-4" />, "#F4D9C6", "Default PDF page size", "Used by Images to PDF",
          <div className="flex gap-1">{["Auto", "A4", "Letter"].map((f) => <button key={f} onClick={(e) => { e.stopPropagation(); upd({ pageSize: f }); }} className={`rounded-full px-2.5 py-1.5 text-[11px] font-extrabold pressable ${s.pageSize === f ? "bg-[#111111] text-white" : "bg-[#F4F3EE]"}`}>{f}</button>)}</div>)}
      </div>

      <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">Privacy & storage</div>
      <div className="space-y-2">
        {row(<HistoryIcon className="h-4 w-4" />, "#CDEFE6", "Tool history", s.historyEnabled ? "Saving metadata locally" : "Paused — nothing recorded", toggle(s.historyEnabled, () => upd({ historyEnabled: !s.historyEnabled })))}
        {row(<Trash2 className="h-4 w-4" />, "#FDF6E9", "Auto-delete temp files", s.autoDeleteTemp ? "Cleaned on launch & export" : "Keep temp previews longer", toggle(s.autoDeleteTemp, () => upd({ autoDeleteTemp: !s.autoDeleteTemp })))}
        {row(<HardDrive className="h-4 w-4" />, "#E8D8F6", "Storage usage", freed ? "Cache cleared ✓" : "Thumbnails + history index",
          <button onClick={(e) => { e.stopPropagation(); saveHistory([]); setFreed(true); setTimeout(() => setFreed(false), 2000); window.dispatchEvent(new CustomEvent("qwik-history")); }} className="pressable shrink-0 rounded-full bg-[#111111] px-3.5 py-2 text-[11px] font-extrabold text-white">{freed ? "Cleared" : "Clear cache"}</button>)}
        {row(<FolderOpen className="h-4 w-4" />, "#F4D9C6", "Permissions", "Camera & files asked per-tool only",
          <span className="rounded-full bg-[#CDEFE6] px-2.5 py-1 text-[11px] font-extrabold">Scoped</span>)}
      </div>

      <div className="rounded-[22px] bg-[#CDEFE6]/60 p-4 text-[12.5px] font-semibold leading-relaxed">
        <b>Privacy promise:</b> QwikTools core processing happens locally on your device. QwikTools does not require a custom file-processing server. No account, no uploads, no tracking in MVP.
      </div>

      <div className="text-xs font-extrabold uppercase tracking-wider text-[#707070]">About</div>
      <div className="space-y-2">
        {row(<Sparkles className="h-4 w-4" />, "#111111", "QwikTools v1.0 MVP", "12 tools · local-first engine", <span className="grid h-8 w-8 place-items-center rounded-full bg-[#F4F3EE] text-white"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#111111] text-[10px] font-black">v1</span></span>)}
        {row(<SlidersHorizontal className="h-4 w-4" />, "#F4F3EE", pro ? "Deactivate Pro (demo)" : "Restore purchase (demo)", "Client-only entitlement",
          <button onClick={(e) => { e.stopPropagation(); setPro(!pro); setProState(!pro); }} className="pressable shrink-0 rounded-full bg-[#111111] px-3.5 py-2 text-[11px] font-extrabold text-white">{pro ? "Deactivate" : "Restore"}</button>)}
      </div>
      <p className="pb-2 text-center text-[11px] font-semibold text-[#8A877D]">Made for Android 10+ · this web preview mirrors the Flutter shell 1:1</p>
    </div>
  );
}
