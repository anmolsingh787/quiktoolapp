import { useCallback, useEffect, useState } from "react";
import { Settings, ShieldCheck } from "lucide-react";
import { TOOLS, isOnboarded, isPro, loadFavs, loadHistory, setOnboarded, toggleFav, touchRecent, type ViewKey } from "./lib/core";
import { BottomNav, Logo, Onboarding, SearchOverlay, Sidebar, Splash, TopBarMobile } from "./components/chrome";
import { HomeScreen, AllTools, CategoryScreen, HistoryScreen, ProScreen, SettingsScreen } from "./screens/misc";
import { QrScanner, QrGenerator } from "./tools/qr";
import { ImageCompressor, ImageResizer, ImageConverter } from "./tools/image";
import { ImagesToPdf, PdfToImages, PdfMerge } from "./tools/pdf";
import { PercentageCalc, UnitConverter } from "./tools/calc";
import { PasswordGen, WordCounter } from "./tools/text";

export default function App() {
  const [boot, setBoot] = useState(true);
  const [onboard, setOnboard] = useState(!isOnboarded());
  const [view, setView] = useState<ViewKey>("home");
  const [searchOpen, setSearchOpen] = useState(false);
  const [favs, setFavs] = useState<string[]>(loadFavs());
  const [histCount, setHistCount] = useState(loadHistory().length);
  const [pro, setProState] = useState(isPro());

  useEffect(() => {
    const t = setTimeout(() => setBoot(false), 1300);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const onHist = () => setHistCount(loadHistory().length);
    const onFav = () => setFavs(loadFavs());
    const onPro = () => setProState(isPro());
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setSearchOpen((v) => !v); }
      if (e.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("qwik-history", onHist);
    window.addEventListener("qwik-favs", onFav);
    window.addEventListener("qwik-pro", onPro);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("qwik-history", onHist);
      window.removeEventListener("qwik-favs", onFav);
      window.removeEventListener("qwik-pro", onPro);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const openTool = useCallback((key: string) => {
    if (key === "tools") { setView("tools"); return; }
    touchRecent(key);
    setView(key);
    setSearchOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const nav = useCallback((v: ViewKey) => {
    setView(v);
    setSearchOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const back = useCallback(() => {
    // smart back: tool -> its category -> tools -> home
    const t = TOOLS.find((x) => x.key === view);
    if (t) { setView(("cat-" + t.category) as ViewKey); window.scrollTo({ top: 0 }); return; }
    if (view.startsWith("cat-")) { setView("tools"); return; }
    setView("home");
  }, [view]);

  const doFav = (key: string) => setFavs(toggleFav(key));
  const isFav = (key: string) => favs.includes(key);

  const renderView = () => {
    if (view === "home") return <HomeScreen onOpen={openTool} onNav={nav} onSearch={() => setSearchOpen(true)} />;
    if (view === "tools") return <AllTools onOpen={openTool} />;
    if (view === "history") return <HistoryScreen onOpen={openTool} />;
    if (view === "pro") return <ProScreen />;
    if (view === "settings") return <SettingsScreen onNav={nav} />;
    if (view === "cat-qr") return <CategoryScreen cat="qr" onOpen={openTool} onBack={back} />;
    if (view === "cat-image") return <CategoryScreen cat="image" onOpen={openTool} onBack={back} />;
    if (view === "cat-pdf") return <CategoryScreen cat="pdf" onOpen={openTool} onBack={back} />;
    if (view === "cat-calc") return <CategoryScreen cat="calc" onOpen={openTool} onBack={back} />;
    if (view === "cat-text") return <CategoryScreen cat="text" onOpen={openTool} onBack={back} />;
    if (view === "qr-scanner") return <QrScanner onBack={back} onFav={() => doFav(view)} fav={isFav(view)} />;
    if (view === "qr-generator") return <QrGenerator onBack={back} onFav={() => doFav(view)} fav={isFav(view)} />;
    if (view === "image-compressor") return <ImageCompressor onBack={back} onFav={() => doFav(view)} fav={isFav(view)} />;
    if (view === "image-resizer") return <ImageResizer onBack={back} onFav={() => doFav(view)} fav={isFav(view)} />;
    if (view === "image-converter") return <ImageConverter onBack={back} onFav={() => doFav(view)} fav={isFav(view)} />;
    if (view === "images-to-pdf") return <ImagesToPdf onBack={back} />;
    if (view === "pdf-to-images") return <PdfToImages onBack={back} />;
    if (view === "pdf-merge") return <PdfMerge onBack={back} />;
    if (view === "percentage") return <PercentageCalc onBack={back} />;
    if (view === "unit-converter") return <UnitConverter onBack={back} />;
    if (view === "password") return <PasswordGen onBack={back} />;
    if (view === "word-counter") return <WordCounter onBack={back} />;
    return <HomeScreen onOpen={openTool} onNav={nav} onSearch={() => setSearchOpen(true)} />;
  };

  const isToolView = TOOLS.some((t) => t.key === view);
  const viewLabel = view === "home" ? "Home" : view === "tools" ? "Tools" : view === "history" ? "History" : view === "pro" ? "Pro" : view === "settings" ? "Settings" : view.startsWith("cat-") ? "Category" : TOOLS.find((t) => t.key === view)?.name || "QwikTools";

  return (
    <div className="min-h-screen bg-[#F7F7F4] text-[#111111]">
      {boot && <Splash />}
      {(!boot && onboard) && <Onboarding onDone={() => { setOnboarded(); setOnboard(false); }} />}

      {/* desktop backdrop texture */}
      <div className="pointer-events-none fixed inset-0 hidden lg:block">
        <div className="absolute -left-40 top-1/4 h-[480px] w-[480px] rounded-full bg-[#CDEFE6]/40 blur-[120px]" />
        <div className="absolute -right-40 top-10 h-[420px] w-[420px] rounded-full bg-[#E8D8F6]/40 blur-[120px]" />
        <div className="absolute bottom-0 left-1/3 h-[380px] w-[380px] rounded-full bg-[#F4D9C6]/40 blur-[120px]" />
      </div>

      <div className="relative mx-auto flex max-w-[1220px] gap-5 px-0 lg:px-5">
        <Sidebar view={view} onNav={nav} onSearch={() => setSearchOpen(true)} histCount={histCount} pro={pro} />

        <main className="min-h-screen flex-1 px-4 pb-32 pt-4 sm:px-6 lg:px-2 lg:pb-16 lg:pt-6">
          <div className="mx-auto w-full max-w-[720px]">
            {/* mobile top */}
            <TopBarMobile onSearch={() => setSearchOpen(true)} onSettings={() => nav("settings")} />

            {/* desktop topbar */}
            <div className="mb-5 hidden items-center gap-3 lg:flex">
              <div className="flex items-center gap-2 text-[13px] font-bold text-[#8A877D]">
                <Logo />
                <span className="mx-1 text-[#D8D5CC]">/</span>
                <span className="rounded-full bg-white px-3 py-1.5 font-extrabold text-[#111111] shadow-sm">{viewLabel}</span>
              </div>
              <div className="ml-auto flex items-center gap-2">
                <span className="flex items-center gap-1.5 rounded-full bg-[#CDEFE6] px-3 py-2 text-[11px] font-extrabold"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-600" /> Offline engine · on-device</span>
                <button onClick={() => nav("settings")} className="pressable grid h-10 w-10 place-items-center rounded-full bg-white shadow-sm hover:bg-[#111111] hover:text-white"><Settings className="h-[18px] w-[18px]" /></button>
              </div>
            </div>

            {/* mobile breadcrumb for tools */}
            {isToolView && <div className="mb-3 mt-4 lg:hidden"><span className="rounded-full bg-white px-3 py-1.5 text-[11px] font-extrabold text-[#707070] shadow-sm">Tools / {viewLabel}</span></div>}
            {isToolView && <div className="h-1 lg:hidden" />}

            <div key={view} className="pop-in">{renderView()}</div>

            {/* footer */}
            <footer className="mt-10 rounded-[26px] bg-[#111111] p-6 text-white">
              <div className="flex flex-wrap items-center gap-3">
                <Logo light />
                <span className="ml-auto flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-[11px] font-extrabold text-white/70"><ShieldCheck className="h-3.5 w-3.5 text-[#CDEFE6]" /> No uploads · No account · No server</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-[12px] font-bold sm:grid-cols-4">
                {[["12 tools", "QR · Image · PDF"], ["100% offline", "Airplane-mode OK"], ["Private", "Local SQLite"], ["Free + Pro", "No subscriptions*"]].map(([a, b]) => (
                  <div key={a} className="rounded-2xl bg-white/[0.07] p-3 ring-1 ring-white/10"><div className="font-extrabold">{a}</div><div className="font-medium text-white/50">{b}</div></div>
                ))}
              </div>
              <p className="mt-4 text-[11px] font-medium leading-relaxed text-white/40">QwikTools is a local utility engine, not a cloud service. Your phone is the compute layer — processing queue, file pipeline, history and tools all run here. *Pro demo in this preview.</p>
            </footer>
            <div className="h-2" />
          </div>
        </main>

        {/* right rail (desktop): context */}
        <aside className="sticky top-6 hidden h-fit w-[280px] shrink-0 space-y-3 xl:block">
          <div className="rounded-[26px] bg-white p-5 shadow-[0_10px_40px_-20px_rgba(17,17,17,0.25)]">
            <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-[#707070]">Popular right now</div>
            <div className="mt-3 space-y-2">
              {["qr-generator", "image-compressor", "pdf-merge"].map((k, i) => {
                const t = TOOLS.find((x) => x.key === k)!;
                return (
                  <button key={k} onClick={() => openTool(k)} className="pressable flex w-full items-center gap-3 rounded-2xl bg-[#F7F7F4] p-2.5 text-left hover:bg-[#111111] hover:text-white group">
                    <span className="font-display text-xs font-extrabold text-[#B9B6AC] group-hover:text-white/40">0{i + 1}</span>
                    <span className="text-[13px] font-extrabold">{t.name}</span>
                    <span className="ml-auto grid h-8 w-8 place-items-center rounded-full bg-[#111111] text-white group-hover:bg-white group-hover:text-[#111111]">→</span>
                  </button>
                );
              })}
            </div>
            <button onClick={() => nav("tools")} className="pressable mt-3 w-full rounded-2xl border-[1.5px] border-[#111111] py-2.5 text-[13px] font-extrabold">All 12 tools</button>
          </div>
          <div className="rounded-[26px] bg-[#E8D8F6] p-5">
            <div className="font-display text-[16px] font-extrabold leading-tight">Files never leave this device.</div>
            <p className="mt-1 text-[12px] font-medium text-[#111111]/65">No conversion API. No object-storage bill. Each phone is its own processing node.</p>
            <div className="mt-3 flex gap-1.5">
              <span className="rounded-full bg-[#111111] px-2.5 py-1 text-[10px] font-extrabold text-white">Isolates</span>
              <span className="rounded-full bg-white/70 px-2.5 py-1 text-[10px] font-extrabold">Streaming</span>
              <span className="rounded-full bg-white/70 px-2.5 py-1 text-[10px] font-extrabold">Memory guard</span>
            </div>
          </div>
          <div className="rounded-[26px] border border-dashed border-[#CFCCC0] p-4 text-[11px] font-semibold text-[#707070]">
            MVP v1.0 · 12/12 tools shipped · Android 10+ shell mirrored 1:1 in this web preview
          </div>
        </aside>
      </div>

      <BottomNav view={view} onNav={nav} onSearch={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} onOpenTool={openTool} />
    </div>
  );
}
